filename=$(date +%Y.%m.%d)

if [ -f $filename.tex ]; then
    echo "File already exists"
else
    touch $filename.tex
fi


