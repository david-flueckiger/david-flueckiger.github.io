<TeXmacs|2.1.1>

<style|generic>

<\body>
  There arise some questions:\ 

  <\question>
    Does <math|0\<less\>p<rsub|c>\<less\>1> occur?
  </question>

  <\exercise>
    Prove that in <math|d=1>,\ 

    <\equation*>
      \<theta\><rsub|1><around*|(|p|)>=0 <text| if <math|p\<less\>1> and
      <math|1> else>
    </equation*>
  </exercise>

  Define

  <\align>
    <tformat|<table|<row|<cell|I=>|<cell|<around*|{|w\<in\>\<Omega\>:<text|<math|\<omega\>>
    contains an infinite cluster>|}>>>|<row|<cell|=>|<cell|<big|cup><rsub|x\<in\>\<bbb-Z\><rsup|d>><around*|{|<around*|\||\<cal-C\><rsub|x>|\|>=+\<infty\>|}>>>>>
  </align>

  <\proposition>
    <label|1.14>The following statements hold:\ 

    <\enumerate>
      <item><label|1.14.a>It holds that <math|\<bbb-P\><rsub|p><around*|(|I|)>\<in\><around*|{|0,1|}>>.\ 

      <item><label|1.14.b><math|\<bbb-P\><rsub|p><around*|(|I|)>=0> if and
      only if <math|\<theta\><around*|(|p|)>=0>.
    </enumerate>
  </proposition>

  <\proof>
    <reference|1.14.a> Enumerate edges of <math|E<rsub|d>> by increasing
    distance from the origin and write <math|E<rsub|d>=<around*|{|\<omega\><rsub|1>,\<omega\><rsub|2>,\<ldots\>|}>>
    Define\ 

    <\equation*>
      I<rsub|n>\<assign\><around*|{|\<omega\>\<in\>\<Omega\>:<text| there is
      infinite cluster in >\<bbb-Z\><rsup|d>\<setminus\>\<Lambda\><rsub|n>|}>.
    </equation*>

    We now claim that <math|I=I<rsub|n>>. Indeed, if we show this, the claim
    follows by Kolmogorov's 0-1-law. The implication
    <math|I\<supseteq\>I<rsub|n>> is obvious. To prove the opposite inclusion
    assume that <math|\<omega\>\<in\>I>. <todo|page 4> We claim that any of
    the <math|C<rsub|i>>'s must intersect
    <math|\<partial\>\<Lambda\><rsub|m>> but
    <math|<around*|\||\<partial\>\<Lambda\><rsub|m>|\|>> is finite so the
    claim follows.\ 

    <reference|1.14.b> We estimate.\ 

    <\equation*>
      \<theta\><around*|(|p|)>=\<bbb-P\><rsub|p><around*|(|<around*|\||\<cal-C\><rsub|0>|\|>=\<infty\>|)>\<leq\>\<bbb-P\><rsub|p><around*|(|I|)>=\<bbb-P\><around*|(|<big|cup><rsub|x\<in\>\<bbb-Z\><rsup|d>><around*|{|<around*|\||\<cal-C\><rsub|x>|\|>=\<infty\>|}>|)>
    </equation*>

    <\equation*>
      <above|\<leq\>|!><big|sum><rsub|x\<in\>\<bbb-Z\><rsup|d>>\<bbb-P\><rsub|p><around*|(|<around*|\||\<cal-C\><rsub|x>|\|>=\<infty\>|)>=<big|sum><rsub|x\<in\>\<bbb-Z\><rsup|d>>\<theta\><around*|(|p|)>,
    </equation*>

    where ! follows from the tranlation invariance of
    <math|\<bbb-P\><rsub|p><around*|(|<around*|\||\<cal-C\><rsub|x>|\|>=\<infty\>|)>>.
    </proof>

  <\theorem>
    <label|2.2>For <math|d\<geq\>2>, <math|p<rsub|c><around*|(|d|)>\<in\><around*|(|0,1|)>>.
    </theorem>

  <\proof>
    <with|font-shape|italic|Step 1.> We show that
    <math|\<theta\><rsub|d><around*|(|<frac|1|2d>|)>=0> which implies that
    <math|p<rsub|c><around*|(|d|)>\<geq\><frac|1|2d>>. Let\ 

    <\equation*>
      \<cal-P\><rsub|n>\<assign\><around*|{|\<gamma\>:<text|<math|\<gamma\>>
      is a path starting in <math|0> of length <math|n>>|}>
    </equation*>

    and observe that

    <\equation*>
      <around*|{|<around*|\||\<cal-C\><rsub|0>|\|>=\<infty\>|}>\<subseteq\><around*|{|\<exists\>\<gamma\>\<in\>\<cal-P\><rsub|n><text|
      where all edges of <math|\<gamma\>> are open>|}>
    </equation*>

    so

    <\align>
      <tformat|<table|<row|<cell|\<theta\><around*|(|p|)>=>|<cell|\<bbb-P\><rsub|p><around*|(|<around*|\||\<cal-C\><rsub|0>|\|>=\<infty\>|)>\<leq\>\<bbb-P\><rsub|p><around*|(|\<exists\>\<gamma\>\<in\>\<cal-P\><rsub|n>,<text|
      <math|\<gamma\>> is open >|)>>>|<row|<cell|\<leq\>>|<cell|<big|sum><rsub|\<gamma\>\<in\>\<cal-P\><rsub|n>><wide*|\<bbb-P\><rsub|p><around*|(|<text|<math|\<gamma\>>
      is open>|)>|\<wide-underbrace\>><rsub|=p<rsup|n>>=p<rsup|n><around*|\||\<cal-P\><rsub|n>|\|>.>>>>
    </align>

    By simple combinatorics one can show that

    <\equation*>
      <around*|\||\<cal-P\><rsub|n>|\|>\<leq\><around*|(|2d|)><around*|(|2d-1|)><rsup|n-1>.
    </equation*>

    Plugging this into the above line and letting
    <math|n\<rightarrow\>+\<infty\>> with <math|p\<leq\><frac|1|2d>>, we
    obtain that <math|\<theta\><around*|(|p|)>=0>.\ 

    <with|font-shape|italic|Step 2.> Let <math|d=2>. We claim that for any
    <math|p\<gtr\><frac|3|4>>, <math|\<theta\><rsub|2><around*|(|p|)>\<gtr\>0>
    (which again implies that <math|p<rsub|c><around*|(|2|)>\<leq\><frac|3|4>>).
    We will use something called <em|Peierls argument>.

    <paragraph|Dual graphs>Let <math|G> be a <em|planar> graph (that is a
    graph that can be drawn without intersecting edges that aren't
    verticies).<todo|page 5>

    <with|font-series|bold|Claim>: There is a bijection between <math|E> and
    <math|E<rsup|\<star\>>> via <math|e<rsup|\<star\>>\<mapsto\>e>.\ 

    In <math|\<bbb-Z\><rsup|2>>, the dual of <math|\<bbb-Z\><rsup|2>> is
    again <math|\<bbb-Z\><rsup|2>> which we call <em|self dual>. We now
    define a <em|dual configuration> living on the dual graph. Let
    <math|\<omega\>\<in\>\<Omega\>>. Define

    <\equation*>
      \<omega\><rsup|\<star\>><around*|(|e<rsup|\<star\>>|)>=<choice|<tformat|<table|<row|<cell|1>|<cell|<text|if
      <math|\<omega\><around*|(|e|)>=0>>>>|<row|<cell|0>|<cell|<text|if
      >\<omega\><around*|(|e|)>=1>>>>>
    </equation*>

    If <math|\<omega\>\<sim\>\<bbb-P\><rsub|p>>, then
    <math|\<omega\><rsup|\<star\>>\<sim\>\<bbb-P\><rsub|1-p>> and if
    <math|\<cal-C\><rsub|0>> is finite, then there is a cylce in
    <math|\<omega\><rsup|\<star\>>> surrounding <math|0> (we are not going to
    show this, exercise). Now,\ 

    <\align>
      <tformat|<table|<row|<cell|1-\<theta\><around*|(|p|)>=>|<cell|\<bbb-P\><rsub|p><around*|(|<around*|\||\<cal-C\><rsub|0>|\|>\<less\>\<infty\>|)>>>|<row|<cell|=>|<cell|\<bbb-P\><rsub|p><around*|(|<big|cup><rsub|n\<in\>\<bbb-N\><rsub|0>><around*|{|<text|<math|\<omega\><rsup|\<star\>>>
      contains an open cylce of length <math|n> surrounding
      0>|}>|)>>>|<row|<cell|\<leq\>>|<cell|<big|sum><rsub|n\<in\>\<bbb-N\><rsub|0>><wide*|\<bbb-P\><rsub|p><around*|(|\<ldots\>|)>|\<wide-underbrace\>><rsub|<around*|(|1-p|)><rsup|n>>>>|<row|<cell|\<leq\>>|<cell|<big|sum><rsub|n\<in\>\<bbb-N\>><around*|(|1-p|)><rsup|n>\<cdot\>#<around*|{|<text|cycles
      around 0 of length <math|n>>|}>.>>>>
    </align>

    If <math|n> is odd or <math|n=2> there are no cylces. A cycle of length
    <math|n> instersects <math|x<rsup|+>>-axis at a point at distance at most
    <math|<frac|n|2>>. From this,\ 

    <\equation*>
      #<around*|{|<text|cycles around 0 of length
      <math|n>>|}>\<leq\><frac|n|2>\<cdot\>3<rsup|n-1>.
    </equation*>

    Pluggin this the claim is proved.\ 

    <with|font-shape|italic|Step 3.> We claim

    <\equation>
      p<rsub|c><around*|(|d|)>\<leq\>p<rsub|c><around*|(|2|)><space|1em>
      <text|for all <math|d\<geq\>2>>.<label|2.2.claimstep3>
    </equation>

    Using that <math|\<bbb-Z\><rsup|2>> can be embedded in
    <math|\<bbb-Z\><rsup|d>> for <math|d\<geq\>2> we have that

    <\equation*>
      \<bbb-P\><rsub|p><around*|(|<around*|\||\<cal-C\><rsub|0>|\|>=\<infty\>|)>\<geq\>\<bbb-P\><rsub|p><around*|(|<around*|\||\<cal-C\><rsub|0>\<cap\>\<bbb-Z\><rsup|2>|\|>=\<infty\>|)>.
      <qedhere>
    </equation*>
  </proof>

  <paragraph|Percolation Toolbox>We have seen some tools:\ 

  <\itemize>
    <item>monotone coupling

    <item>duality (<math|\<bbb-Z\><rsup|2>>).\ 

    <item>Harris-FKG-inequality (see below)
  </itemize>

  Goal: If <math|A,B> are events and <math|\<bbb-P\><around*|(|A|)>,\<bbb-P\><around*|(|B|)>>
  known, can we estimate <math|\<bbb-P\><around*|(|A\<cap\>B|)>>? This is
  trivially easy if <math|A> and <math|B> are independent but not otherwise.

  <paragraph|Intuition.><math|x,y,u,v\<in\>\<bbb-Z\><rsup|d>> and let
  <math|e> be an edge. One would expect

  <\equation*>
    \<bbb-P\><rsub|p><around*|(|x\<leftrightarrow\>y|)>\<leq\>\<bbb-P\><rsub|p><around*|(|x\<leftrightarrow\>y\<mid\><text|<math|e>
    open>|)>.
  </equation*>

  Similarly,\ 

  <\equation*>
    \<bbb-P\><rsub|p><around*|(|x\<rightarrow\>y|)>\<leq\>\<bbb-P\><rsub|p><around*|(|x\<leftrightarrow\>y\<mid\>u\<leftrightarrow\>v|)>.
  </equation*>

  <\theorem>
    <dueto|Harris-FKG-inequality ><label|2.3>

    <\enumerate>
      <item>If <math|A,B> are increasing events

      <\equation*>
        \<bbb-P\><rsub|p><around*|(|A\<cap\>B|)>\<geq\>\<bbb-P\><rsub|p><around*|(|A|)>\<bbb-P\><rsub|p><around*|(|B|)>.
      </equation*>

      <item>If <math|f,g\<in\>L<rsup|2><around*|(|\<bbb-P\><rsub|p>|)>> are
      increasing

      <\equation*>
        \<bbb-E\><rsub|p><around*|[|f g|]>\<geq\>\<bbb-E\><rsub|p><around*|[|f|]>\<bbb-E\><rsub|p><around*|[|g|]>.
        </equation*>
    </enumerate>
  </theorem>

  <\remark>
    <\itemize>
      <item>If we replace by <math|f> by <math|-f> and <math|g> by <math|-g>
      we can also put decreasing and the equality still holds.\ 

      <item>The proof does not use the geometry of <math|\<bbb-Z\><rsup|d>>,
      it only uses the properties of the product measure.

      <item>FKG holds even for some non-product measure.
    </itemize>
  </remark>

  <\proof>
    <dueto|of Theorem <reference|2.3>><with|font-shape|italic|Step 1>: Assume
    that <math|f,g> only depend on finitely many edges. We again enumerate
    the edges <math|E<rsub|d>=<around*|{|e<rsub|1>,e<rsub|2>,\<ldots\>|}>>
    and write <math|\<omega\><rsub|i>\<assign\>\<omega\><around*|(|e<rsub|i>|)>>.
    If <math|f,g:<around*|{|0,1|}><rsup|n>\<rightarrow\>\<bbb-R\>>, we claim

    <\equation>
      \<bbb-E\><rsub|p><around*|[|f<around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|n>|)>g<around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|n>|)>|]>\<geq\>\<bbb-E\><rsub|p><around*|[|f<around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|n>|)>|]>\<bbb-E\><rsub|p><around*|[|g<around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|n>|)>|]>.<label|star2.3>
    </equation>

    We prove this claim by induction: For <math|n=1>,
    <math|a,b\<in\><around*|{|0,1|}>>we have\ 

    <\equation*>
      <around*|(|f<around*|(|a|)>-f<around*|(|b|)>|)><around*|(|g<around*|(|a|)>-g<around*|(|b|)>|)>\<geq\>0
    </equation*>

    so multiplying by <math|\<bbb-P\><rsub|p><around*|(|\<omega\><rsub|1>=a|)>\<bbb-P\><around*|(|\<omega\><rsub|1>=b|)>\<geq\>0>
    and summing over all <math|a,b> gives us\ 

    <\equation*>
      2<around*|(|\<bbb-E\><rsub|p><around*|[|f
      g|]>-\<bbb-E\><rsub|p><around*|[|f|]>\<bbb-E\><rsub|p><around*|[|g|]>|)>\<geq\>0.
      </equation*>

    Assume that <eqref|star2.3> holds for <math|n\<leq\>k>. Then\ 

    <\align>
      <tformat|<table|<row|<cell|\<bbb-E\><rsub|p><around*|[|<around*|(|f\<cdot\>g|)><around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|k+1>|)>|]>=>|<cell|p
      \<bbb-E\><rsub|p><around*|[|<around*|(|f\<cdot\>g|)><around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|k>,1|)>|]>>>|<row|<cell|>|<cell|+<around*|(|1-p|)>\<bbb-E\><rsub|p><around*|[|<around*|(|f\<cdot\>g|)><around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|k>,0|)>|]>>>|<row|<cell|<above|\<geq\>|Ind>>|<cell|p<wide*|\<bbb-E\><rsub|p><around*|[|f<around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|k>,1|)>|]>|\<wide-underbrace\>><rsub|<wide|
      f|~><around*|(|1|)>><wide*|\<bbb-E\><rsub|p><around*|[|g<around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|k>,1|)>|]>|\<wide-underbrace\>><rsub|<wide|g|~><around*|(|1|)>>>>|<row|<cell|>|<cell|+<around*|(|1-p|)><wide*|\<bbb-E\><rsub|p><around*|[|f<around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|k>,0|)>|]>|\<wide-underbrace\>><rsub|<wide|
      f|~><around*|(|0|)>><wide*|\<bbb-E\><rsub|p><around*|[|g<around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|k>,0|)>|]>|\<wide-underbrace\>><rsub|<wide|g|~><around*|(|0|)>>>>|<row|<cell|=>|<cell|\<bbb-E\><rsub|p><around*|[|<wide|f|~><wide|g|~>|]>>>|<row|<cell|<above|\<geq\>|Ind>>|<cell|\<bbb-E\><rsub|p><around*|[|<wide|f|~>|]>\<bbb-E\><rsub|p><around*|[|<wide|g|~>|]>>>|<row|<cell|=>|<cell|\<bbb-E\><rsub|p><around*|[|f|]>\<bbb-E\><rsub|p><around*|[|g|]>,>>>>
    </align>

    where we used that <math|<wide|f|~>> and <math|<wide|g|~>> are
    increasing.\ 

    <with|font-shape|italic|Step 2:> (infinite volume). Take <math|f,g> as in
    the theorem and define

    <\equation*>
      f<rsub|n>\<assign\>\<bbb-E\><rsub|p><around*|[|f\<mid\>\<sigma\><around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|n>|)>|]>,<space|1em>
      g<rsub|n>\<assign\>\<bbb-E\><rsub|p><around*|[|g\<mid\>\<sigma\><around*|(|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|n>|)>|]>.
    </equation*>

    Then <math|f<rsub|n>,g<rsub|n>> only depend on
    <math|\<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|n>> and are increasing.
    Then <math|f<rsub|n>,g<rsub|n>>, <math|n\<in\>\<bbb-N\>> are martingales
    bounded in <math|L<rsup|2><around*|(|\<bbb-P\><rsub|p>|)>>. So by
    martingale convergence theorem we have

    <\equation*>
      f<rsub|n><long-arrow|\<rubber-rightarrow\>|L<rsup|2>>f,<space|1em>
      g<rsub|n><long-arrow|\<rubber-rightarrow\>|L<rsup|2>>g
    </equation*>

    but convergence in <math|L<rsup|2>> implies convergence in
    <math|L<rsup|1>> and thus we have convergence of the products
    <math|f<rsub|n>g<rsub|n>>. So by this reasoning and the previous step,\ 

    <\align>
      <tformat|<table|<row|<cell|\<bbb-E\><rsub|p><around*|[|f
      g|]>=>|<cell|lim<rsub|n\<rightarrow\>+\<infty\>>\<bbb-E\><rsub|p><around*|[|f<rsub|n>g<rsub|n>|]>\<geq\>lim<rsub|n\<rightarrow\>+\<infty\>>\<bbb-E\><rsub|p><around*|[|f<rsub|n>|]>\<bbb-E\><around*|[|g<rsub|n>|]>>>|<row|<cell|=>|<cell|\<bbb-E\><rsub|p><around*|[|f|]>\<bbb-E\><rsub|p><around*|[|g|]>.<qedhere>>>>>
    </align>
  </proof>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|1.14|<tuple|1|1>>
    <associate|1.14.a|<tuple|1|1>>
    <associate|1.14.b|<tuple|2|1>>
    <associate|2.2|<tuple|2|1>>
    <associate|2.2.claimstep3|<tuple|1|2>>
    <associate|2.3|<tuple|3|3>>
    <associate|auto-1|<tuple|1|2>>
    <associate|auto-2|<tuple|2|2>>
    <associate|auto-3|<tuple|3|3>>
    <associate|claimstep3|<tuple|1|?>>
    <associate|star2.3|<tuple|2|3>>
  </collection>
</references>

<\auxiliary>
  <\collection>
    <\associate|toc>
      <with|par-left|<quote|4tab>|Dual graphs
      <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-1><vspace|0.15fn>>

      <with|par-left|<quote|4tab>|Percolation Toolbox
      <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-2><vspace|0.15fn>>

      <with|par-left|<quote|4tab>|Intuition.
      <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-3><vspace|0.15fn>>
    </associate>
  </collection>
</auxiliary>