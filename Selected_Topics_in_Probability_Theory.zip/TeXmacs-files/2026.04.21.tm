<TeXmacs|2.1.1>

<style|generic>

<\body>
  <\proposition>
    <label|16.16>Suppose that <math|\<pi\><around*|(|V|)>\<less\>+\<infty\>>.
    Then the random walk <math|X> on the weighted graph
    <math|<around*|(|G,\<mu\>|)>> is recurrent.\ 
  </proposition>

  <\proof>
    Fix <math|z\<in\>G> and define <math|\<varphi\><around*|(|x|)>\<assign\>\<up-P\><rsub|x><around*|(|H<rsub|z>=+\<infty\>|)>>.
    Note that <math|\<varphi\>> is bounded and since
    <math|\<pi\><around*|(|V|)>\<less\>+\<infty\>>
    <math|\<varphi\>\<in\>L<rsup|2>\<subseteq\>H<rsup|2>>. For
    <math|x\<neq\>z>,\ 

    <\equation*>
      \<varphi\><around*|(|x|)>=<big|sum><rsub|y\<in\>V>\<up-P\><rsub|x><around*|(|X<rsub|n>=y,H<rsub|z>=+\<infty\>|)>=<big|sum><rsub|y\<in\>V>p<around*|(|x,y|)>\<varphi\><around*|(|y|)>,
    </equation*>

    that is, <math|\<varphi\>> is harmonic on
    <math|V\<setminus\><around*|{|z|}>> with
    <math|\<varphi\><around*|(|z|)>=0>. Since <math|\<varphi\>> is bounded we
    can apply discrete Green Gauss Theorem (<todo|todo numbering>):\ 

    <\equation*>
      \<cal-E\><around*|(|\<varphi\>,\<varphi\>|)>=-<around|\<langle\>|\<varphi\>,\<Delta\>\<varphi\>|\<rangle\>><rsub|\<pi\>>=<wide*|\<varphi\><around*|(|z|)>|\<wide-underbrace\>><rsub|=0>\<Delta\>\<varphi\><around*|(|z|)>\<pi\><around*|(|z|)>=0
    </equation*>

    which implies by (<with|font-series|bold|??>) that <math|\<varphi\>> must
    be constant, i.e., <math|\<varphi\>\<equiv\> 0>.\ 
  </proof>

  <paragraph|Killed process>Given a graph <math|G=<around*|(|V,E|)>> with
  weights <math|\<mu\>> let <math|A\<subseteq\>V>. We set\ 

  <\equation*>
    T<rsub|A>=inf<around*|{|n\<in\>\<bbb-N\><rsub|0>\<mid\>X<rsub|n>\<nin\>A|}>
  </equation*>

  the exit time of <math|A> and\ 

  <\equation*>
    p<rsub|n><rsup|A><around*|(|x,y|)>=<frac|1|\<pi\><around*|(|y|)>>\<up-P\><rsub|x><around*|(|X<rsub|n>=y,T<rsub|A>\<gtr\>n|)>
  </equation*>

  the transition density of <math|X> killed on exiting <math|A>. We define
  the following operators:\ 

  <\align>
    <tformat|<table|<row|<cell|Id<rsub|A>f<around*|(|x|)>=>|<cell|f<around*|(|x|)><with|font-series|bold|1><rsub|A><around*|(|x|)>>>|<row|<cell|P<rsup|A><rsub|n>f<around*|(|x|)>=>|<cell|<big|sum><rsub|y\<in\>A>p<rsub|n><rsup|A><around*|(|x,y|)>\<pi\><around*|(|y|)>f<around*|(|y|)>
    <long-arrow|\<rubber-equal\>|<text|if
    <math|x\<in\>A>>>\<up-E\><rsub|x><around*|[|f<around*|(|X<rsub|1>|)><with|font-series|bold|1><rsub|T<rsub|A>\<gtr\>1>|]>,<space|1em>
    n\<geq\>1>>|<row|<cell|\<Delta\><rsub|A>=>|<cell|P<rsup|A>-Id<rsub|A>.>>>>
  </align>

  <\remark>
    In general <math|P<rsup|A>> is a \Psub-Markovian\Q operator, i.e., Mass
    can disappear for example when <math|X> hits <math|A>.\ 
  </remark>

  <math|P<rsup|A>> has many properties similar to <math|P>.

  <\lemma>
    <label|17.1>The following statements hold:\ 

    <\enumerate>
      <item><math|p<rsub|n><rsup|A><around*|(|x,y|)>=0> if <math|x\<nin\>A>
      or <math|y\<nin\>A> and <math|p<rsub|n><rsup|A><around*|(|x,y|)>=p<rsub|1><around*|(|y,x|)>>
      for all <math|x,y\<in\>A>.\ 

      <item>We have that

      <\align>
        <tformat|<table|<row|<cell|p<rsub|n+m><rsup|A><around*|(|x,y|)>=>|<cell|<big|sum><rsub|z\<in\>V<text|
        or >z\<in\>A>p<rsub|n><rsup|A><around*|(|x,z|)>p<rsub|n><rsup|A><around*|(|z,y|)>\<pi\><around*|(|z|)>>>|<row|<cell|p<rsub|n+1><rsup|A><around*|(|x,y|)>-p<rsub|n><rsup|A><around*|(|x,y|)>=>|<cell|\<Delta\><rsub|y>p<rsub|n><rsup|A><around*|(|x,y|)>,>>>>
      </align>

      the discrete heat equation (second line).\ 

      <item><math|P<rsub|n><rsup|A>=<around*|(|P<rsup|A>|)><rsup|\<circ\>n>>
      and <math|P<rsub|A>f=Id<rsub|A> P Id<rsub|A>f >,
      <math|\<Delta\><rsub|A>f=Id<rsub|A> \<Delta\>Id<rsub|A>f>.
    </enumerate>
  </lemma>

  <\proof>
    Similar to to the case where <math|A=V>.\ 
  </proof>

  <paragraph|Green's function>Analoguous to <with|font-family|ss|Stochastic
  Analysis> we define Green's function.\ 

  <\definition>
    The function <math|g<rsub|A>:V\<times\>V\<rightarrow\>\<bbb-R\><rsub|\<geq\>0>\<cup\><around*|{|+\<infty\>|}>>
    given by

    <\equation*>
      g<rsub|A><around*|(|x,y|)>=<big|sum><rsub|n=0><rsup|+\<infty\>>p<rsub|n><rsup|A><around*|(|x,y|)>
    </equation*>

    is called <em|Green's function> or <em|Green's density>. As a convention:
    <math|g\<assign\>g<rsub|V>>.\ 
  </definition>

  We record some elementary properties of Green's function whose proofs are
  left as an exercise to the reader.\ 

  <\itemize>
    <item><math|g<rsub|A>> is symmetric, that is
    <math|g<rsub|A><around*|(|x,y|)>=g<rsub|A><around*|(|y,x|)>> for all
    <math|x,y\<in\>V>.\ 

    <item>We have

    <\equation*>
      g<rsub|A><around*|(|x,y|)>=<frac|1|\<pi\><around*|(|y|)>>\<up-E\><rsub|x><around*|[|<big|sum><rsub|n=0><rsup|+\<infty\>><with|font-series|bold|1><rsub|X<rsub|n>=y,n\<less\>T<rsub|A>>|]>
    </equation*>

    where the sum in the expectation is the number of visits to <math|y>
    before exiting <math|A>.\ 

    <item>If <math|<around*|(|G,\<mu\>|)>> is recurrent,
    <math|g<around*|(|x,y|)>=+\<infty\>> for all <math|x,y\<in\>V>. If
    <math|<around*|(|G,\<mu\>|)>> is transient,
    <math|g<around*|(|x,y|)>\<less\>+\<infty\>> for all <math|x,y\<in\>V>.\ 

    <item>If <math|A\<neq\>V>, then <math|g<rsub|A><around*|(|x,y|)>\<less\>+\<infty\>>.
  </itemize>

  Next is a useful idendity for <math|g<rsub|A>>

  <\theorem>
    <label|17.2>Suppose that either <math|A\<neq\>V> or <math|X> is
    transient, that is, <math|g<around*|(|x,y|)>\<less\>+\<infty\>> for all
    <math|x,y\<in\>V>. Then

    <\enumerate>
      <item><math|g<rsub|A><around*|(|x,y|)>=\<up-P\><rsub|x><around*|(|H<rsub|y>\<less\>T<rsub|A>|)>g<rsub|A><around*|(|y,y|)>>
      for all <math|x,y\<in\>V> and

      <item><math|\<pi\><around*|(|y|)>g<rsub|A><around*|(|y,y|)>=<frac|1|\<up-P\><rsub|y><around*|(|T<rsub|A>\<less\><wide|H|~><rsub|y>|)>>=<frac|1|\<up-P\><rsub|y><around*|(|T<rsub|A>\<leq\><wide|H|~><rsub|y>|)>>>
      for <math|y\<in\>A>.\ 
    </enumerate>
  </theorem>

  <\proof>
    <todo|See notes>
  </proof>

  <\exercise>
    The formulas of the above theorem are very intuitive, explain why.
  </exercise>

  <\theorem>
    <label|17.3>If <math|x,y\<in\>A> then\ 

    <\equation*>
      \<Delta\><rsub|y>g<rsub|A><around*|(|x,y|)>=-\<pi\><around*|(|x|)>\<delta\><rsub|x,y>,
    </equation*>

    where <math|\<delta\>> denotes the Kronecker-Delta and
    <math|\<mathLaplace\><rsub|y>> denotes the Laplacian applied in the
    <math|y>-argument of the function.\ 
  </theorem>

  <\proof>
    Note that\ 

    <\align>
      <tformat|<table|<row|<cell|P g<rsub|A><around*|(|x,y|)>=>|<cell|<big|sum><rsub|z\<in\>V><wide|p<around*|(|y,z|)>\<pi\><around*|(|z|)>|\<wide-overbrace\>><rsup|\<up-P\><rsub|y><around*|(|X<rsub|1>=z|)>>g<rsub|A><around*|(|x,z|)>>>|<row|<cell|=>|<cell|<big|sum><rsub|z\<in\>V><big|sum><rsub|n\<in\>\<bbb-N\><rsub|0>>p<around*|(|y,z|)>\<pi\><around*|(|z|)>p<rsub|n><rsup|A><around*|(|x,z|)>>>|<row|<cell|<long-arrow|\<rubber-equal\>|!>>|<cell|<big|sum><rsub|n\<in\>\<bbb-N\><rsub|0>>p<rsub|n+1><rsup|A><around*|(|x,y|)>>>|<row|<cell|=>|<cell|g<rsub|A><around*|(|x,y|)>-p<rsub|0><rsup|A><around*|(|x,y|)>=g<rsub|A><around*|(|x,y|)>-<frac|\<delta\><rsub|x,y>|\<pi\><around*|(|y|)>>,>>>>
    </align>

    where we used at ! that every term in the above sums is positive, that is
    we can use monotone convergence to swap sums and also the
    Chapmann-Kolmogorov-equality. The claim follows by using
    <math|\<Delta\>=P-Id>.\ 
  </proof>

  <\definition>
    Let <math|A\<subseteq\>V> and <math|f:<wide|A|\<bar\>>=A\<cup\>\<partial\>A\<rightarrow\>\<bbb-R\>>.
    <math|f> is <em|harmonic> on <math|A> if
    <math|\<Delta\>f<around*|(|x|)>=0> for all <math|x\<in\>A>. We call
    <math|f> <em|superharmonic> if <math|-\<Delta\>f<around*|(|x|)>\<geq\>0>
    for all <math|x\<in\>V> and subharmonic if
    <math|-\<Delta\>f<around*|(|x|)>\<leq\>0> for all <math|x\<in\>V>.
  </definition>

  <\theorem>
    <dueto|Maximum principle>Let <math|A\<subseteq\>V> be connected and
    <math|h:<wide|A|\<bar\>>\<rightarrow\>\<bbb-R\>> subharmonic on <math|A>.\ 

    <\enumerate>
      <item><label|DMP, i>If there exists some <math|x\<in\>A> such that
      <math|h<around*|(|x|)>=max<rsub|<wide|A|\<bar\>>>h> then <math|h> is
      constant.\ 

      <item><label|DMP, ii>If <math|A> is finite then <math|h> attains its
      maximum on <math|<wide|A|\<bar\>>> and the maximum is attained on the
      boundary <math|\<partial\>A>.\ 
    </enumerate>
  </theorem>

  <\proof>
    <reference|DMP, i> Let <math|x> be the value where the maximum is
    attained. Let <math|B=<around*|{|y\<in\>V\<mid\>h<around*|(|y|)>=h<around*|(|x|)>|}>>.
    Then for <math|y\<in\>B\<cap\>A> we have for all <math|z\<sim\>y> that
    <math|h<around*|(|z|)>\<leq\>h<around*|(|y|)>>. Also,\ 

    <\align>
      <tformat|<table|<row|<cell|0\<leq\>>|<cell|\<pi\><around*|(|y|)>\<Delta\><around*|(|y|)>>>|<row|<cell|=>|<cell|<big|sum><rsub|z\<sim\>y>\<mu\><rsub|y,z><wide*|<around*|(|h<around*|(|z|)>-h<around*|(|y|)>|)>|\<wide-underbrace\>><rsub|\<leq\>0>\<leq\>0>>>>
    </align>

    that is <math|h<around*|(|z|)>=h<around*|(|y|)>> for all
    <math|z\<sim\>y>. This means we can repeat the above argument with all
    neighbouring points. Since <math|A> is connected, <math|h> must be
    constant on <math|A>, that is <math|B=A>.\ 

    <reference|DMP, ii> <todo|>
  </proof>

  <\theorem>
    <label|17.6>Assume that <math|<around*|(|G,\<mu\>|)>> is recurrent. If
    <math|f> is a nonnegative function that is superharmonic on <math|V>,
    then <math|f> is constant.\ 
  </theorem>

  <\proof>
    Since <math|f> is superharmonic and nonnegative,
    <math|M<rsub|n>=f<around*|(|X<rsub|n>|)>> is a non-negative
    super-martingale, hence the limit

    <\equation>
      <label|limMartingale>lim<rsub|n\<rightarrow\>+\<infty\>>f<around*|(|X<rsub|n>|)>
    </equation>

    exists and is finite <math|\<up-P\><rsub|x>>-a.s. On the other hand
    <math|X> visits every point infinitely often <math|\<up-P\><rsub|x>>-a.s.
    so <math|f> must be constant (otherwise the limit <eqref|limMartingale>
    does not exist).\ 
  </proof>

  <\theorem>
    <label|17.7><dueto|Forster's criterion><math|<around*|(|G,\<mu\>|)>> is
    recurrent if and only if there exists some <math|A\<subseteq\>V> finite
    and <math|h:V\<rightarrow\><around*|[|0,+\<infty\>|)>> such that <math|h>
    is superharmonic on <math|V\<setminus\>A> and for any
    <math|M\<less\>+\<infty\>> the sublevel set

    <\equation*>
      <around*|{|x\<in\>V\<mid\>h<around*|(|x|)>\<leq\>M|}>
    </equation*>

    is finite.
  </theorem>

  <\proof>
    <math|\<Longleftarrow\>>: Suppose we have found such <math|A> and
    <math|h> as in the theorem. Then <math|M<rsub|n>=h<around*|(|X<rsub|n\<wedge\>H<rsub|A>>|)>>
    is a non-negative supermartingale, hence the limit
    <math|lim<rsub|n\<rightarrow\>+\<infty\>>M<rsub|n>\<in\><around*|[|0,+\<infty\>|)>>
    exists <math|\<up-P\><rsub|x>>-a.s. for all <math|x\<in\>V>. Suppose by
    contradiction that <math|X> is transient. Then there exists
    <math|x\<in\>V> such that <math|\<up-P\><rsub|x><around*|(|H<rsub|A>\<less\>+\<infty\>|)>\<less\>1>.
    But then <math|\<up-P\><rsub|x><around*|(|lim
    M<rsub|n>=+\<infty\>|)>\<gtr\>0> because the sublevel set of <math|h> is
    finite (since you hit every point a.s. finitely many times the limit has
    to be infinite).\ 

    <math|\<Longrightarrow\>>: Let <math|B<rsub|n>=B<around*|(|A,n|)>> the
    ball of size <math|n> around <math|A>. Let

    <\equation*>
      h<rsub|n><around*|(|x|)>=\<up-P\><rsub|x><around*|(|T<rsub|B<rsub|n>>\<less\>H<rsub|A>|)>.
    </equation*>

    Then <math|h> is superharmonic on <math|V\<setminus\>A> and
    <math|h\<equiv\>1> on <math|B<rsub|n><rsup|\<complement\>>> and
    <math|h<rsub|n><around*|(|x|)>\<searrow\>0> as
    <math|n\<rightarrow\>+\<infty\>> by recurrence (exercise: fill in the
    details). Let <math|h<rsub|n<rsub|k>>> be a subsequence such that
    <math|h<rsub|n<rsub|k>><around*|(|x|)>\<leq\>2<rsup|-k>> for all
    <math|x\<in\>B<rsub|k>>. Let\ 

    <\equation*>
      h=<big|sum><rsub|k\<geq\>0>h<rsub|n<rsub|k>>.
    </equation*>

    Then <math|h> is superharmonic on <math|V\<setminus\>A> and
    <math|h\<geq\>0> and <math|h<around*|(|x|)>\<less\>+\<infty\>> for all
    <math|x\<in\>V>, <math|h<around*|(|x|)>\<geq\>M> for all
    <math|x\<in\>B<rsub|n<rsub|k>><rsup|\<complement\>>>, that is <math|h>
    has the required properties. \ 
  </proof>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|16.16|<tuple|1|1>>
    <associate|17.1|<tuple|3|1>>
    <associate|17.2|<tuple|5|2>>
    <associate|17.3|<tuple|6|2>>
    <associate|17.6|<tuple|9|3>>
    <associate|17.7|<tuple|10|3>>
    <associate|DMP, i|<tuple|1|3>>
    <associate|DMP, ii|<tuple|2|3>>
    <associate|auto-1|<tuple|1|1>>
    <associate|auto-2|<tuple|2|2>>
    <associate|auto-3|<tuple|3|?>>
    <associate|limMartingale|<tuple|1|3>>
  </collection>
</references>

<\auxiliary>
  <\collection>
    <\associate|toc>
      <with|par-left|<quote|4tab>|Killed process
      <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-1><vspace|0.15fn>>

      <with|par-left|<quote|4tab>|Green's function
      <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-2><vspace|0.15fn>>
    </associate>
  </collection>
</auxiliary>