<TeXmacs|2.1.1>

<style|generic>

<\body>
  <chapter|Random Walks on Weighted Graphs>

  <with|font-series|bold|Literature: Barlow. >

  This field has a lot of similarities with the analysis of parabolic PDEs.
  It is easier than RWRE so we will also cover <math|d\<geq\>2>. This will be
  the last big part of the lecture.\ 

  <\example>
    <label|16.1>Consider the random walk among random conductness, that is
    let <math|G=<around*|(|\<bbb-Z\><rsup|d>,E<rsub|d>|)>> and let
    <math|\<mu\>=<around*|(|\<mu\><rsub|e>|)><rsub|e\<in\>E<rsub|d>>> the
    conductances which we assume to be independent under <math|\<bbb-P\>>. We
    assume ellipticity, that is there exists some
    <math|\<varepsilon\>\<gtr\>0> such that\ 

    <\equation*>
      \<bbb-P\><around*|(|\<varepsilon\>\<leq\>\<mu\><rsub|e>\<leq\><frac|1|\<varepsilon\>>|)>=1<space|1em>
      <text|for all <math|e\<in\>E<rsub|d>>.>
    </equation*>

    Consider a random walk <math|X> such that, given <math|\<mu\>>,\ 

    <\equation*>
      P<rsup|\<mu\>><around*|(|x,y|)>=\<up-P\><rsup|\<mu\>><around*|(|X<rsub|1>=y\<mid\>X<rsub|0>=x|)>=<frac|\<mu\><rsub|x,y>|<big|sum><rsub|z\<sim\>x>\<mu\><rsub|x,z>>.
    </equation*>

    This is always reversible.
  </example>

  <paragraph|Fact.>The random walk in random environment in the reccurrent
  situation grows really slowly,

  <\equation*>
    <frac|X<rsub|n>|log<rsup|2>n>\<sim\>b<rsub|n>
  </equation*>

  RWRC is alway recurrent and

  <\equation*>
    <frac|X<rsub|n t>|<sqrt|n>>\<rightarrow\>B<rsub|t>,
  </equation*>

  where <math|B> is a Brownian motion. Compared to RWRE where we had
  <math|\<pi\><around*|(|x|)>\<asymp\>\<mathe\><rsup|V<around*|(|x|)>>> and
  <math|V<around*|(|x|)>> is a random walk again, the invariant measure of
  RWRC is <math|\<pi\><around*|(|x|)>=\<mu\><rsub|x,x+1>+\<mu\><rsub|x,x-1>>.\ 

  <\notation>
    The notation will at some times be slightly different than in the
    previous lectures. Here <math|G=<around*|(|V,E|)>> will denote a graph
    (which will often be infinite) and we will write <math|x\<sim\>y> iff
    <math|<around*|{|x,y|}>\<in\>E>. Here we will use the word path for a
    finite squence <math|x<rsub|0>,\<ldots\>,x<rsub|n>\<in\>V> with
    <math|x<rsub|i>\<sim\>x<rsub|i-1>> (note that a path does not need to be
    self avoiding here!). Moreover we define the degree of a vertex
    <math|v\<in\>V>

    <\equation*>
      deg<around*|(|v|)>\<assign\>#<around*|{|z\<in\>V\<mid\>z\<sim\>x|}>.
    </equation*>

    We say that <math|G> has <em|bounded geometry> iff y

    <\equation*>
      sup<around*|{|deg<around*|(|x|)>\<mid\>x\<in\>V|}>\<less\>+\<infty\>.
    </equation*>
  </notation>

  <with|font-series|bold|Assumption.> We assume that our graph
  <math|G=<around*|(|V,E|)>> is <em|locally finite>.\ 

  <\definition>
    <label|16.4>A weight (conductance) is a function
    <math|\<mu\>:V\<times\>V\<rightarrow\>\<bbb-R\><rsub|\<geq\>0>>,
    <math|<around*|(|x,y|)>\<mapsto\>\<mu\><rsub|x,y>> with the following
    properties:\ 

    <\itemize>
      <item><math|\<mu\>> is symmetric, that is
      <math|\<mu\><rsub|x,y>=\<mu\><rsub|y,x>>.\ 

      <item>If <math|x\<neq\>y>, <math|\<mu\><rsub|x,y>\<gtr\>0> if and only
      if <math|x\<sim\>y>, that is <math|<around*|{|x,y|}>\<in\>E>.\ 
    </itemize>

    Moreoever we define\ 

    <\equation*>
      \<pi\><around*|(|x|)>:=<big|sum><rsub|z\<in\>V>\<mu\><rsub|x,z>=<big|sum><rsub|z\<sim\>x>\<mu\><rsub|x,z>+\<mu\><rsub|x,x>.
      </equation*>

    We call the pair <math|<around*|(|G,\<mu\>|)>> <em|weighted graph>.\ 
  </definition>

  <\remark>
    A natural choice for a weight would be
    <math|\<mu\><rsub|x,y>=<with|font-series|bold|1><rsub|x\<sim\>y>>. If we
    do not specify a weight function we implicitely use this.\ 
  </remark>

  <\definition>
    <label|16.5>A weighted graph <math|<around*|(|G,\<mu\>|)>> has bounded
    weights if there exists <math|C\<in\>\<bbb-R\><rsub|\<geq\>0>> such that

    <\equation*>
      <text|for any <math|e\<in\>E>,><space|1em>
      \<mu\><rsub|e>\<in\><around*|[|C<rsup|-1>,C|]>.\ 
    </equation*>

    We say that <math|<around*|(|G,\<mu\>|)>> has controlled weights if there
    exists <math|C\<gtr\>0> such that\ 

    <\equation*>
      <text|for any <math|x\<sim\>y>><space|1em>
      <frac|\<mu\><rsub|x,y>|\<pi\><around*|(|x|)>>\<geq\>C.
    </equation*>

    At last we define <math|P<around*|(|x,y|)>=<frac|\<mu\><rsub|x,y>|\<pi\><around*|(|x|)>>>,
    where <math|P<around*|(|x,y|)>\<gtr\>0> implies that either
    <math|x\<sim\>y> or <math|x=y>.\ 
  </definition>

  <\exercise>
    If we have controlled weights then <math|G> has bounded geometry.\ 
  </exercise>

  Let <math|<around*|(|X<rsub|n>|)><rsub|n\<in\>\<bbb-N\><rsub|0>>> be a
  random walkon <math|<around*|(|G,\<mu\>|)>> with transition matrix <math|P>
  (it is only a matrix if <math|G> is finite). Moreover we denote by
  <math|\<up-P\><rsub|x>> the law of <math|X> given <math|X<rsub|0>=x>.\ 

  <\lemma>
    <\itemize>
      <item><label|16.6><math|X> is reversible and <math|\<pi\>> is its
      reversible measure.\ 

      <item>For any <math|x<rsub|0>,\<ldots\>,x<rsub|n>\<in\>V> we have\ 

      <\equation*>
        \<pi\><around*|(|x<rsub|0>|)>\<up-P\><rsub|x<rsub|0>><around*|(|X<rsub|1>=x<rsub|1>,\<ldots\>,X<rsub|n>=x<rsub|n>|)>=\<pi\><around*|(|x<rsub|n>|)>\<up-P\><rsub|x<rsub|n>><around*|(|X<rsub|1>=x<rsub|n>,\<ldots\>,X<rsub|n>=x<rsub|0>|)>.
      </equation*>
    </itemize>
  </lemma>

  <\proof>
    The easy proof is left as an exercise to the reader.\ 
  </proof>

  <\remark>
    Every reversible chain is RWRC.\ 
  </remark>

  <todo|16.7>

  We know that the Random Walk on <math|\<bbb-Z\><rsup|d>> is recurrent if
  and only if <math|d\<leq\>2>.\ 

  <\question>
    <\itemize>
      <item>Is RW on a triangular/hexagonal lattice in <math|d=2> recurrent?

      <item>Is RW on <math|<around*|(|\<bbb-Z\><rsup|d>,\<mu\>|)>> where
      <math|\<mu\>> are bounded weights recurrent if <math|d\<leq\>2>?

      <item>Do the above Random Walks have a Brownian motion limit?
    </itemize>
  </question>

  We will look at the so-called <em|heat kernel bound>:\ 

  <\equation*>
    p<rsub|n><around*|(|x,y|)>\<asymp\><frac|c<rsub|1>|n<rsup|d/2>>\<mathe\><rsup|-c<rsub|2><frac|<around*|\||x-y|\|><rsup|2>|n>>.
    </equation*>

  We define the <em|transition densities> by

  <\equation*>
    p<rsub|n><around*|(|x,y|)>=<frac|1|\<pi\><around*|(|y|)>>P<rsup|n><around*|(|x,y|)>=<frac|1|\<pi\><around*|(|y|)>>\<up-P\><rsub|x><around*|(|X<rsub|n>=y|)>.
  </equation*>

  <\lemma>
    <\itemize>
      <item><label|16.8>The Chapmann Kolmogorov-equation holds:\ 

      <\equation*>
        p<rsub|n+m><around*|(|x,y|)>=<big|sum><rsub|z\<in\>V>p<rsub|n><around*|(|x,z|)>p<rsub|n><around*|(|z,y|)>\<pi\><around*|(|z|)>=<big|int><rsub|V>p<rsub|n><around*|(|x,z|)>p<rsub|n><around*|(|z,y|)>\<pi\><around*|(|\<mathd\>z|)>.
      </equation*>

      <item>It holds that <math|p<rsub|n><around*|(|x,y|)>=p<rsub|n><around*|(|y,x|)>>
      for any <math|n\<in\>\<bbb-N\><rsub|0>> and <math|x,y\<in\>V>.\ 

      <item>The <math|p<rsub|n>>'s are normalized in the sense that\ 

      <\equation*>
        <big|int><rsub|V>p<rsub|n><around*|(|x,z|)>\<pi\><around*|(|\<mathd\>z|)>=1.
      </equation*>
    </itemize>
  </lemma>

  <\definition>
    Denote <math|C<around*|(|V|)>=<around*|{|f:V\<rightarrow\>\<bbb-R\>|}>>
    (<math|C> because all functions <math|V\<rightarrow\>\<bbb-R\>> are
    continuous if we equipp <math|V> with the discrete topology). Denote
    <math|C<rsub|0><around*|(|V|)>> the set of all functions with finite
    support. and denote <math|L<rsup|p>=L<rsup|p><around*|(|V,\<pi\>|)>>. As
    usual <math|L<rsup|2>> is a Hilbert space and we denote

    <\equation*>
      <around|\<langle\>|f,g|\<rangle\>>\<assign\><around|\<langle\>|f,g|\<rangle\>><rsub|\<pi\>>:=<around|\<langle\>|f,g|\<rangle\>><rsub|L<rsup|2><around*|(|\<pi\>|)>>=<big|sum><rsub|x\<in\>V>f<around*|(|x|)>g<around*|(|x|)>\<pi\><around*|(|x|)>.
    </equation*>

    The transition densities can be viewed as an operator given by

    <\equation*>
      P<rsub|n>f<around*|(|x|)>=<big|sum><rsub|y\<in\>V>P<rsup|n><around*|(|x,y|)>f<around*|(|y|)>=\<up-E\><rsub|x><around*|[|f<around*|(|X<rsub|n>|)>|]>.
    </equation*>
  </definition>

  <\definition>
    We define the <em|probabilitistic Laplace operator> by
    <math|\<Delta\>=P-Id> i.e.,\ 

    <\align>
      <tformat|<table|<row|<cell|\<Delta\>f<around*|(|x|)>=>|<cell|<around*|(|P
      f|)><around*|(|x|)>-f<around*|(|x|)>=\<up-E\><rsub|x><around*|[|f<around*|(|X<rsub|1>|)>|]>-f<around*|(|x|)>>>|<row|<cell|=>|<cell|<big|sum><rsub|y\<in\>V>p<around*|(|x,y|)><around*|(|f<around*|(|y|)>-f<around*|(|x|)>|)>\<pi\><around*|(|y|)>>>|<row|<cell|=>|<cell|<frac|1|\<pi\><around*|(|x|)>><big|sum><rsub|y\<in\>V>\<mu\><rsub|x,y><around*|(|f<around*|(|x|)>-f<around*|(|y|)>|)>.>>>>
    </align>

    This is the \Pgenerator\Q of the Markov-chain <math|X>.
  </definition>

  We have the following elementary properties of <math|P> and
  <math|\<Delta\>> whose proof are left as an exercise to ther reader.\ 

  <\lemma>
    <label|16.11>

    <\enumerate>
      <item>The function <math|f\<equiv\>1> is an eigenfunction of <math|P>
      i.e., <math|\<Delta\>1=0>.\ 

      <item><math|P> and <math|\<Delta\>> are self-adjoint in
      <math|L<rsup|2><around*|(|\<pi\>|)>> that is for any
      <math|f,g\<in\>L<rsup|2>>,\ 

      <\equation*>
        <around|\<langle\>|f,P g|\<rangle\>>=<around|\<langle\>|P
        f,g|\<rangle\>>,<space|1em> <around|\<langle\>|f,\<Delta\>g|\<rangle\>>=<around|\<langle\>|\<Delta\>f,g|\<rangle\>>,
      </equation*>

      <item>The operator-norms of <math|P> and <math|\<Delta\>> satisfy

      <\equation*>
        <around*|\<\|\|\>|P|\<\|\|\>><rsub|L<rsup|p>\<rightarrow\>L<rsup|p>>\<leq\>1,<space|1em>
        <around*|\<\|\|\>|\<Delta\>|\<\|\|\>><rsub|L<rsup|p>\<rightarrow\>L<rsup|p>>\<leq\>2.
      </equation*>
    </enumerate>
  </lemma>

  <section|Dirichlet (Energy)-form>

  <\definition>
    Let <math|f,g\<in\>C<around*|(|V|)>>. The quadratic form

    <\equation>
      <label|definitionofE>\<cal-E\><around*|(|f,g|)>=<frac|1|2><big|sum><rsub|x,y\<in\>V>\<mu\><rsub|x,y><around*|(|f<around*|(|x|)>-f<around*|(|y|)>|)><around*|(|g<around*|(|x|)>-g<around*|(|y|)>|)>
    </equation>

    is defined if the above series is absolutely convergent and in this case
    we call <math|\<cal-E\>> the <em|Dirichlet (Energy)-form>.\ 
  </definition>

  <\remark>
    To see why it is called Dirichlet-Energy, compare it with the expression

    <\equation*>
      <big|int><rsub|\<Omega\>>\<nabla\>f<around*|(|x|)>\<cdot\>\<nabla\>g<around*|(|x|)>\<mathd\>x.
    </equation*>

    where the discrete gradients are given by
    <math|f<around*|(|x|)>-f<around*|(|x-1|)>>. We will see later why we
    named it that way. At this point in time the name is random.\ 
  </remark>

  <\definition>
    We define the space\ 

    <\equation*>
      H<rsup|2>=H<rsup|2><around*|(|G,\<mu\>|)>=<around*|{|f\<in\>C<around*|(|V|)>\<mid\>f<text|
      is such that <eqref|definitionofE> converges absolutely>|}>.\ 
    </equation*>

    The norm on <math|H<rsup|2>> is given by

    <\equation*>
      <around*|\<\|\|\>|f|\<\|\|\>><rsub|H<rsup|2>><rsup|2>=\<cal-E\><around*|(|f,f|)>+f<around*|(|o|)><rsup|2>,
    </equation*>

    where <math|o> is a base point of the graph (like an arbitrarily fixed
    origin).\ 
  </definition>

  <\lemma>
    <label|16.13>

    <\enumerate>
      <item>If <math|x\<sim\>y> we have\ 

      <\equation*>
        <around*|\||f<around*|(|x|)>-f<around*|(|y|)>|\|>\<leq\><sqrt|<frac|\<cal-E\><around*|(|f,f|)>|\<mu\><rsub|x,y>>>.
        </equation*>

      <item><math|\<cal-E\><around*|(|f,f|)>=0> if and only if
      <math|f\<equiv\>const>.<\footnote>
        This explains why we needed to add <math|f<rsup|2><around*|(|o|)>> in
        the definition of <math|<around*|\<\|\|\>|\<cdot\>|\<\|\|\>><rsub|H<rsup|2>><rsup|2>>.
        </footnote>

      <item><label|16.13, iii>For <math|f\<in\>L<rsup|2>> we have that
      <math|\<cal-E\><around*|(|f,f|)>\<leq\>2<around*|\<\|\|\>|f|\<\|\|\>><rsub|L<rsup|2>><rsup|2>>,
      so <math|L<rsup|2>\<subseteq\>H<rsup|2>>.\ 

      <item>The space <math|H<rsup|2>> is a Hilbert space with the scalar
      product

      <\equation*>
        <around|\<langle\>|f,g|\<rangle\>><rsub|H<rsup|2>>=\<cal-E\><around*|(|f,g|)>+f<around*|(|o|)>g<around*|(|o|)>.
      </equation*>

      <item>Convergence in <math|H<rsup|2>> implies convergence pointwise
      convergene <em|everywhere>.\ 
    </enumerate>
  </lemma>

  <\proof>
    We have that\ 

    <\equation*>
      \<cal-E\><around*|(|f,f|)>=<frac|1|2><big|sum><rsub|x,y>\<mu\><rsub|x,y><around*|(|f<around*|(|x|)>-f<around*|(|y|)>|)><rsup|2>\<leq\>2
      <big|sum><rsub|x>f<around*|(|x|)><rsup|2><big|sum><rsub|y>\<mu\><rsub|x,y>=2<around*|\<\|\|\>|f|\<\|\|\>><rsub|L<rsup|2>><rsup|2>,
    </equation*>

    which shows <reference|16.13, iii>. The rest of the points are left as an
    exercise to the reader.\ 
  </proof>

  In the following we will establish an analogon of the famous Green-Gauss
  theorem from analysis.

  <\theorem>
    <dueto|Green, Gauss><label|16.15>If <math|f,g\<in\>C<around*|(|V|)>> are
    such that\ 

    <\equation>
      <big|sum><rsub|x,y\<in\>V><around*|\||g<around*|(|x|)>|\|>\<cdot\><around*|\||f<around*|(|x|)>-f<around*|(|y|)>|\|>\<mu\><rsub|x,y>\<less\>+\<infty\>,<label|GreenGaussCondition>
    </equation>

    then\ 

    <\equation*>
      \<cal-E\><around*|(|f,g|)>=-<around|\<langle\>|\<Delta\>f,g|\<rangle\>><rsub|L<rsup|2><around*|(|\<pi\>|)>>.
      </equation*>
  </theorem>

  <\proof>
    Note that <eqref|GreenGaussCondition> ensures that all the series used in
    the following proof converge absolutely. Using that
    <math|\<mu\><rsub|x,y>=\<mu\><rsub|y,x>>

    <\align>
      <tformat|<table|<row|<cell|\<cal-E\><around*|(|f,g|)>=>|<cell|<frac|1|2><big|sum><rsub|x,y><around*|(|f<around*|(|y|)>-f<around*|(|x|)>|)>g<around*|(|y|)>\<mu\><rsub|x,y>-<frac|1|2><big|sum><rsub|x,y><around*|(|f<around*|(|y|)>-f<around*|(|x|)>|)>g<around*|(|x|)>\<mu\><rsub|x,y>>>|<row|<cell|=>|<cell|<frac|1|2><big|sum><rsub|x,y><around*|(|f<around*|(|x|)>-f<around*|(|y|)>|)>g<around*|(|x|)>\<mu\><rsub|x,y>-<frac|1|2><big|sum><rsub|x,y><around*|(|f<around*|(|y|)>-f<around*|(|x|)>|)>g<around*|(|x|)>\<mu\><rsub|x,y>>>|<row|<cell|=>|<cell|-<big|sum><rsub|x>g<around*|(|x|)><wide*|<big|sum><rsub|y><around*|(|f<around*|(|y|)>-f<around*|(|x|)>|)><frac|\<mu\><rsub|x,y>|\<pi\><around*|(|x|)>>|\<wide-underbrace\>><rsub|=\<Delta\>f>\<pi\><around*|(|x|)>>>|<row|<cell|=>|<cell|-<around|\<langle\>|g,\<Delta\>f|\<rangle\>><rsub|\<pi\>>.
      <qedhere>>>>>
    </align>
  </proof>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|16.1|<tuple|1|1|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|16.11|<tuple|11|3|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|16.13|<tuple|15|4|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|16.13, iii|<tuple|3|4|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|16.15|<tuple|16|4|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|16.4|<tuple|3|1|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|16.5|<tuple|5|2|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|16.6|<tuple|<with|mode|<quote|math>|\<bullet\>>|2|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|16.8|<tuple|<with|mode|<quote|math>|\<bullet\>>|3|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|GreenGaussCondition|<tuple|2|?|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|auto-1|<tuple|1|1|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|auto-2|<tuple|1|1|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|auto-3|<tuple|1|4|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|definitionofE|<tuple|1|4|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|footnote-1|<tuple|1|4|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|footnr-1|<tuple|1|4|../.TeXmacs/texts/scratch/no_name_10.tm>>
  </collection>
</references>

<\auxiliary>
  <\collection>
    <\associate|toc>
      <vspace*|2fn><with|font-series|<quote|bold>|math-font-series|<quote|bold>|font-size|<quote|1.19>|1<space|2spc>Random
      Walks on Weighted Graphs> <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-1><vspace|1fn>

      <with|par-left|<quote|4tab>|Fact. <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-2><vspace|0.15fn>>

      <vspace*|1fn><with|font-series|<quote|bold>|math-font-series|<quote|bold>|1<space|2spc>Dirichlet
      (Energy)-form> <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-3><vspace|0.5fn>
    </associate>
  </collection>
</auxiliary>