<TeXmacs|2.1.1>

<style|generic>

<\body>
  Note that the coupling, FKG, BK and Russo work on <em|any> graph, not just
  <math|\<bbb-Z\><rsup|d>>.\ 

  <section|Ergodicity, Mixing>

  Consider <math|G=<around*|(|\<bbb-Z\><rsup|d>,E<rsub|d>|)>>. The additive
  group <math|<around*|(|\<bbb-Z\><rsup|d>,+|)>> acts

  <\itemize>
    <item>on <math|\<bbb-Z\><rsup|d>> by translation,\ 

    <item>on <math|E<rsub|d>> by <math|z\<cdot\><around*|{|x,y|}>=<around*|{|x+z,x+y|}>>.

    <item>on <math|\<Omega\>=<around*|{|0,1|}><rsup|E<rsub|d>>> by
    <math|<around*|(|z\<cdot\>\<omega\>|)><around*|{|x,y|}>=\<omega\><around*|(|<around*|{|x-z,y-z|}>|)>>.
    Note that <math|e> is open in <math|\<omega\>> iff <math|z\<cdot\>e> is
    open in <math|\<omega\>>.\ 

    <item>on <math|\<cal-A\>> via <math|z\<cdot\>A=<around*|{|z\<cdot\>\<omega\>:\<omega\>\<in\>A|}>>.
    </itemize>

  <\example>
    <math|z*<around*|{|x\<leftrightarrow\>\<infty\>|}>=<around*|{|z+x\<leftrightarrow\>\<infty\>|}>>.
  </example>

  <\lemma>
    <dueto|<math|\<bbb-P\><rsub|p>> is translation invariant><label|4.1>For
    any <math|A\<in\>\<cal-A\>> and for any <math|z\<in\>\<bbb-Z\><rsup|d>>

    <\equation*>
      \<bbb-P\><rsub|p><around*|(|z\<cdot\>A|)>=\<bbb-P\><rsub|p><around*|(|A|)>.
    </equation*>
  </lemma>

  <\proof>
    Define the translated measure <math|<around*|(|z\<cdot\>\<bbb-P\><rsub|p>|)><around*|(|A|)>\<assign\>\<bbb-P\><rsub|p><around*|(|z\<cdot\>A|)>>.
    Consider <math|A> that depends on the state of finitely many elements
    (cylinder events) i.e., we take

    <\equation>
      A=<big|cap><rsub|i=1><rsup|n><around*|{|\<omega\>\<in\>\<Omega\>:\<omega\><around*|(|e<rsub|i>|)>=\<omega\><rsub|i>|}>,<space|1em>
      e<rsub|1,>,\<ldots\>,e<rsub|n>\<in\>E,<space|1em>
      \<omega\><rsub|1>,\<ldots\>,\<omega\><rsub|n>\<in\><around*|{|0,1|}>,<label|formA>
    </equation>

    so we have that

    <\equation*>
      <around*|(|z\<cdot\>\<bbb-P\><rsub|p>|)><around*|(|A|)>=\<bbb-P\><rsub|p><around*|(|z\<cdot\>A|)>=\<ldots\>=\<bbb-P\><rsub|p><around*|(|A|)>.
    </equation*>

    Then conclude by Dynkin's lemma, as the sets of the form <math|A> form a
    <math|\<pi\>>-system.

    <todo|complete proof>
  </proof>

  <\proposition>
    <dueto|Mixing><label|4.2>Let <math|A,B\<in\>\<cal-A\>> (we are still
    working on <math|\<bbb-Z\><rsup|d>>). Then

    <\equation*>
      lim<rsub|<around*|\<\|\|\>|z|\<\|\|\>><rsub|1>\<rightarrow\>+\<infty\>>\<bbb-P\><rsub|p><around*|(|A\<cap\><around*|(|z\<cdot\>B|)>|)>=\<bbb-P\><rsub|p><around*|(|A|)>\<bbb-P\><rsub|p><around*|(|B|)>.
      </equation*>
  </proposition>

  We first need a lemma, approximating the above by cylinder events.

  <\lemma>
    <label|4.2>For any <math|A\<in\>\<cal-A\>> and
    <math|\<varepsilon\>\<gtr\>0> there exists <math|A<rsub|\<varepsilon\>>>
    of the form <eqref|formA> (we denote the collection of all such sets as
    <math|\<cal-C\>>) such that <math|\<bbb-P\><rsub|p><around*|(|A\<triangle\>A<rsub|\<varepsilon\>>|)>\<leq\>\<varepsilon\>>.
    </lemma>

  <\proof>
    Define

    <\equation*>
      \<cal-D\>\<assign\><around*|{|A\<in\>\<cal-A\>:\<forall\>\<varepsilon\>\<gtr\>0\<exists\>A<rsub|\<varepsilon\>>\<in\>\<cal-C\><text|
      s.t. >\<bbb-P\><rsub|p><around*|(|A\<triangle\>A<rsub|\<varepsilon\>>|)>\<leq\>\<varepsilon\>|}>.
    </equation*>

    Then one can prove that

    <\itemize>
      <item><math|\<Omega\>\<in\>\<cal-D\>>,\ 

      <item><math|\<cal-C\>\<subseteq\>\<cal-D\>> and

      <item><math|\<cal-D\>> is a <math|\<lambda\>>-system
    </itemize>

    so we conclude by Dynkin's lemma.\ 
  </proof>

  <\proof>
    <dueto|Proof of Proposition <reference|4.2>>Fix
    <math|\<varepsilon\>\<gtr\>0> and <math|A<rsub|\<varepsilon\>>,B<rsub|\<varepsilon\>>\<in\>\<cal-A\>>
    such that\ 

    <\equation*>
      \<bbb-P\><rsub|p><around*|(|A\<triangle\>A<rsub|\<varepsilon\>>|)>,\<bbb-P\><rsub|p><around*|(|B\<triangle\>B<rsub|\<varepsilon\>>|)>\<leq\>\<varepsilon\>.
    </equation*>

    As <math|A<rsub|\<varepsilon\>>,B<rsub|\<varepsilon\>>\<in\>\<cal-C\>>,
    the formula holds for them. So we have that\ 

    <\align>
      <tformat|<table|<row|<cell|\<bbb-P\><rsub|p><around*|(|A\<cap\><around*|(|z\<cdot\>B|)>|)>>|<cell|\<leq\>\<bbb-P\><rsub|p><around*|(|A<rsub|\<varepsilon\>>\<cap\><around*|(|z\<cdot\>B|)>|)>+2\<varepsilon\>=<rsup|<text|<math|z>
      large>>\<bbb-P\><rsub|p><around*|(|A<rsub|\<varepsilon\>>|)>\<bbb-P\><rsub|p><around*|(|B<rsub|\<varepsilon\>>|)>+2\<varepsilon\>\<leq\>\<bbb-P\><rsub|p><around*|(|A|)>\<bbb-P\><rsub|p><around*|(|B|)>+4\<varepsilon\>.>>>>
    </align>

    The lower bound follows analogously.\ 
  </proof>

  <\theorem>
    <label|4.4>Let <math|A\<in\>\<cal-A\>> be invariant, that is
    <math|z\<cdot\>A=A> for any <math|z\<in\>\<bbb-Z\><rsup|d>>. Then
    <math|\<bbb-P\><rsub|p><around*|(|A|)>\<in\><around*|{|0,1|}>>.
  </theorem>

  <\proof>
    Since <math|A=z\<cdot\>A> we have by Proposition <reference|4.2>,

    <\equation*>
      \<bbb-P\><rsub|p><around*|(|A|)>=lim<rsub|<around*|\<\|\|\>|z|\<\|\|\>><rsub|1>\<rightarrow\>+\<infty\>>\<bbb-P\><around*|(|A\<cap\><around*|(|z\<cdot\>A|)>|)>=\<bbb-P\><rsub|p><around*|(|A|)>\<bbb-P\><rsub|p><around*|(|A|)>.<qedhere>
    </equation*>
  </proof>

  <\example>
    <\itemize>
      <item>Obivously <math|<around*|{|\<omega\>\<in\>\<Omega\>:\<omega\><text|
      contains infinite cluster>|}>=I> is translation invariant so by our
      previous theorem we have <math|\<bbb-P\><rsub|p><around*|(|I|)>\<in\><around*|{|0,1|}>>.\ 

      <item>Define <math|I<rsub|k>\<assign\><around*|{|\<omega\>\<in\>\<Omega\>:\<omega\><text|
      contains exactly <math|k> infinite clusters>|}>>,
      <math|k\<in\>\<bbb-N\><rsub|0>\<cup\><around*|{|\<infty\>|}>> is again
      translation invariant. So also <math|\<bbb-P\><rsub|p><around*|(|I<rsub|k>|)>\<in\><around*|{|0,1|}>>.
      This means the random variable

      <\equation*>
        N<around*|(|\<omega\>|)>=#<text|of> infinite clusters in \<omega\>.
      </equation*>

      is <math|\<bbb-P\><rsub|p>>-a.s. constant.
    </itemize>
  </example>

  <\question>
    Find <math|k> such that <math|\<bbb-P\><rsub|p><around*|(|N=k|)>=1>.
  </question>

  <chapter|Uniqueness of infinite clusters>

  <\theorem>
    <dueto|Aizuman, Kesten, Newman, 1987><label|4.5>For any
    <math|d\<in\>\<bbb-N\>>, <math|p\<in\><around*|[|0,1|]>> either

    <\itemize>
      <item><math|\<bbb-P\><rsub|p><around*|(|N=0|)>=1> or

      <item><math|\<bbb-P\><rsub|p><around*|(|N=1|)>=1>.
    </itemize>
  </theorem>

  \ The proof we will show here is due to Burton and Keave (1989).\ 

  <\proof>
    Throughout the proof assume that <math|p\<in\><around*|(|0,1|)>>. If
    <math|p=0> there <math|\<bbb-P\><rsub|p>>-a.s. does not exist an infinite
    cluster and if <math|p=1>, <math|\<bbb-P\><rsub|p>>-a.s. every edge is
    open. We already know that there exists
    <math|k\<in\>\<bbb-N\><rsub|0>\<cup\><around*|{|\<infty\>|}>> such that
    <math|\<bbb-P\><rsub|p><around*|(|N=k|)>=1>.\ 

    <with|font-shape|italic|Step 1: <math|k\<in\><around*|{|0,1,\<infty\>|}>>.>
    Suppose that <math|1\<less\>k\<less\>\<infty\>> meaning
    <math|\<bbb-P\><rsub|p><around*|(|N=1|)>=0>. Define the event

    <\equation*>
      F<rsub|n>\<assign\><around*|{|\<omega\>\<in\>\<Omega\>:<text|all
      <math|k> infinite clusters in <math|\<omega\>> touch the box
      <math|\<Lambda\><rsub|n>>>|}>.\ 
    </equation*>

    We already know that <math|lim<rsub|n\<rightarrow\>+\<infty\>>\<bbb-P\><rsub|p><around*|(|F<rsub|n>|)>=1>
    so there exists <math|n\<in\>\<bbb-N\>> such that
    <math|\<bbb-P\><rsub|p><around*|(|F<rsub|n>|)>\<geq\><frac|1|2>>. Now,

    <\align>
      <tformat|<table|<row|<cell|\<bbb-P\><rsub|p><around*|(|N=1|)>\<geq\>>|<cell|\<bbb-P\><rsub|p><around*|(|F<rsub|n>\<cap\><around*|{|<text|all
      edges in <math|\<Lambda\><rsub|n>> are
      open>|}>|)>>>|<row|<cell|=>|<cell|\<bbb-P\><rsub|p><around*|(|F<rsub|n>|)>\<bbb-P\><rsub|p><around*|(|<text|all
      edges in <math|\<Lambda\><rsub|n>> are
      open>|)>>>|<row|<cell|\<geq\>>|<cell|<frac|1|2>\<cdot\>p<rsup|<around*|\||E<around*|(|\<Lambda\><rsub|n>|)>|\|>>\<gtr\>0>>>>
    </align>

    if <math|p\<gtr\>0>.

    which is a contradiction.\ 

    <\definition>
      <math|x\<in\>\<bbb-Z\><rsup|d>> is a <em|trifurcation> in
      <math|\<omega\>> if<todo|Bild 12>

      <\itemize>
        <item><math|x> is incident to exactly 3 open edges in
        <math|\<omega\>>.\ 

        <item>if these 3 edges are removed from <math|\<omega\>>,
        <math|\<cal-C\><rsub|x>> separates into 3 infinite clusters.\ 
      </itemize>

      Denote

      <\equation*>
        T<rsub|x>\<assign\><around*|{|\<omega\>\<in\>\<Omega\>:<text|<math|x>
        is trifurcation in <math|\<omega\>>>|}>
      </equation*>
    </definition>

    <with|font-shape|italic|Step 2: If <math|\<bbb-P\><rsub|p><around*|(|N\<geq\>3|)>\<gtr\>0>
    then <math|\<bbb-P\><rsub|p><around*|(|T<rsub|0>\<gtr\>0|)>>>. Define\ 

    <\align>
      <tformat|<table|<row|<cell|B<rsub|n>\<assign\>>|<cell|<around*|{|x\<in\>\<bbb-Z\><rsup|d>:<around*|\<\|\|\>|x|\<\|\|\>><rsub|1>\<leq\>n|}>>>|<row|<cell|E<rsub|n>:=>|<cell|<around*|{|<text|at
      least <math|3> infinite clusters touch
      <math|B<rsub|n>>>|}>>>|<row|<cell|E<rsub|n><around*|(|x,y,z|)>\<assign\>>|<cell|<around*|{|<text|outside
      of <math|B<rsub|n>>, <math|\<cal-C\><rsub|x>,\<cal-C\><rsub|y>,\<cal-C\><rsub|z>>
      are infinite and disjoint>|}>.>>>>
    </align>

    For <math|n> large,

    <\equation*>
      0\<less\>\<bbb-P\><rsub|p><around*|(|E<rsub|n>|)>=\<bbb-P\><rsub|p><around*|(|<big|cup><rsub|<below|x,y,z\<in\>\<partial\>B<rsub|n>|x\<neq\>y\<neq\>z>>E<rsub|n><around*|(|x,y,z|)>|)>\<leq\><big|sum><rsub|x,y,z\<in\>\<partial\>B<rsub|m>>\<bbb-P\><rsub|p><around*|(|E<rsub|n><around*|(|x,y,z|)>|)>
    </equation*>

    so there exists <math|n\<in\>\<bbb-N\>> and
    <math|x,y,z\<in\>\<partial\>B<rsub|n>> such that
    <math|\<bbb-P\><rsub|p><around*|(|E<rsub|n><around*|(|x,y,z|)>|)>\<gtr\>0>.
    Take <math|\<gamma\><rsub|x>,\<gamma\><rsub|y>,\<gamma\><rsub|z>> as in
    the picture <todo|Bild 13> such that the paths are pairwise disjoint.
    Then\ 

    <\equation*>
      \<bbb-P\><rsub|p><around*|(|T<rsub|0>|)>\<geq\>\<bbb-P\><rsub|p><around*|(|E<rsub|n><around*|(|x,y,z|)>\<cap\><around*|{|<text|all
      edges in <math|\<gamma\><rsub|x>,\<gamma\><rsub|y>,\<gamma\><rsub|z>>
      are open and all other edges in <math|B<rsub|n>> are closed>|}>|)>
    </equation*>

    <\equation*>
      =\<bbb-P\><rsub|p><around*|(|E<rsub|n><around*|(|x,y,z|)>|)>\<bbb-P\><rsub|n><around*|(|\<ldots\>|)>
    </equation*>

    <with|font-shape|italic|Step 3: For any
    <math|p\<in\><around*|(|0,1|)>,\<bbb-P\><rsub|p><around*|(|N=\<infty\>|)>=0>.>
    We assume by contradiction that <math|\<bbb-P\><rsub|p><around*|(|N=\<infty\>|)>=1>.
    By the previous step <math|\<bbb-P\><rsub|p><around*|(|T<rsub|0>|)>=const\<gtr\>0>.
    Define the random variable

    <\equation*>
      \<cal-T\><rsub|n>\<assign\>#<text|trifurcation in
      <math|\<Lambda\><rsub|n>>.>
    </equation*>

    Then

    <\equation>
      \<bbb-E\><rsub|p><around*|[|\<cal-T\><rsub|n>|]>=<big|sum><rsub|x\<in\>\<Lambda\><rsub|n>>\<bbb-P\><rsub|p><around*|(|<text|<math|x>
      is trifurcation>|)>=<around*|\||\<Lambda\><rsub|n>|\|>\<cdot\>\<bbb-P\><rsub|p><around*|(|T<rsub|0>|)>=\<cal-O\><around*|(|n<rsup|d>|)>.
      <label|ordernd>
    </equation>

    We claim

    <\equation>
      <label|claimlecture4>\<forall\>\<omega\>\<in\>\<Omega\><space|1em>
      <around*|\||\<cal-T\><rsub|n><around*|(|\<omega\>|)>|\|>\<leq\><around*|\||\<partial\>\<Lambda\><rsub|n>|\|>=\<cal-O\><around*|(|n<rsup|d-1>|)>.
      </equation>

    If we prove this we get a contradiction to <eqref|ordernd> and can
    conclude the proof.<todo|Rest of the proof peeling proceedure.>\ 

    <\lemma>
      <label|combinatoriallemma>Let <math|T=<around*|(|V,E|)>> be a finite
      tree. Define

      <\equation*>
        N<rsub|k>\<assign\><around*|{|x\<in\>V:deg<around*|(|x|)>=k|}>
      </equation*>

      <\equation*>
        N<rsub|\<geq\>k>=<around*|{|x\<in\>V:deg<around*|(|x|)>\<geq\>k|}>.
      </equation*>

      Then <math|<around*|\||N<rsub|1>|\|>\<geq\>2+<around*|\||N<rsub|\<geq\>3>|\|>\<geq\><around*|\||N<rsub|\<geq\>3>|\|>>.
      </lemma>

    After peeling <math|N<rsub|1>\<subseteq\>\<partial\>\<Lambda\><rsub|n>>
    and <math|N<rsub|\<geq\>3>\<supseteq\>\<cal-T\><rsub|n>>. So applying the
    above lemma to every component of the peeled forest yields

    <\equation*>
      <around*|\||\<cal-T\><rsub|n>|\|>\<leq\><around*|\||N<rsub|\<geq\>3>|\|>\<leq\><around*|\||N<rsub|1>|\|>\<leq\><around*|\||\<partial\>\<Lambda\><rsub|n>|\|>.
      </equation*>

    This concludes the proof of the theorem.\ 
  </proof>

  <\proof>
    <dueto|Proof of Lemma <reference|combinatoriallemma>>Observe that
    <math|<around*|\||V|\|>=<around*|\||E|\|>+1>. Moreover,\ 

    <\equation*>
      2<around*|\||E|\|>=<big|sum><rsub|x\<in\>V>deg
      <around*|(|x|)>\<geq\><around*|\||N<rsub|1>|\|>+2<around*|\||N<rsub|2>|\|>+3<around*|\||N<rsub|\<geq\>3>|\|>.
    </equation*>

    Also,

    <\equation*>
      2<around*|\||E|\|>=2<around*|(|<around*|\||V|\|>-1|)>=2
      <around*|\||N<rsub|1>|\|>+2<around*|\||N<rsub|2>|\|>+2<around*|\||N<rsub|\<geq\>3>|\|>-2.
    </equation*>

    Substract the equations:\ 

    <\equation*>
      <around*|\||N<rsub|1>|\|>\<geq\><around*|\||N<rsub|\<geq\>3>|\|>+2.<qedhere>
    </equation*>
  </proof>

  <paragraph|Percolation on <math|\<bbb-T\><rsup|d>>>Let
  <math|\<bbb-T\><rsup|d>> denote an infinite tree where every vertex has
  degree <math|3>. <todo|Bild 14>Then one can prove that there exist
  <math|0\<less\>p<rsub|1>\<less\>p<rsub|2>\<less\>1> such that\ 

  <\equation*>
    \<bbb-P\><rsub|p><around*|(|N=0|)>=1,<space|1em> <text|for
    <math|p\<less\>p<rsub|1>>>
  </equation*>

  <\equation*>
    \<bbb-P\><rsub|p><around*|(|N=\<infty\>|)>=1<space|1em> <text|for
    <math|p<rsub|1>\<less\>p\<less\>p<rsub|2>>>
  </equation*>

  and

  <\equation*>
    \<bbb-P\><rsub|p><around*|(|N=1|)>=1,<space|1em> <text|for
    <math|p\<gtr\>p<rsub|2>>>.
  </equation*>

  The reason why the above proof does not work here is that the surface of
  the ball grows proportionally to the volume on <math|\<bbb-T\><rsup|d>>.\ 
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|4.1|<tuple|2|?>>
    <associate|4.2|<tuple|4|?>>
    <associate|4.4|<tuple|5|?>>
    <associate|4.5|<tuple|7|?>>
    <associate|auto-1|<tuple|1|1>>
    <associate|auto-2|<tuple|1|?>>
    <associate|auto-3|<tuple|1|?>>
    <associate|claimlecture4|<tuple|3|?>>
    <associate|combinatoriallemma|<tuple|9|?>>
    <associate|formA|<tuple|1|?>>
    <associate|ordernd|<tuple|2|?>>
  </collection>
</references>

<\auxiliary>
  <\collection>
    <\associate|toc>
      <vspace*|1fn><with|font-series|<quote|bold>|math-font-series|<quote|bold>|1<space|2spc>Ergodicity,
      Mixing> <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-1><vspace|0.5fn>
    </associate>
  </collection>
</auxiliary>