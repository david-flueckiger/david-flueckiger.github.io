<TeXmacs|2.1.1>

<style|generic>

<\body>
  <\lemma>
    <label|14.1>If <math|\<bbb-E\><around*|[|log \<rho\><rsub|0>|]>\<leq\>0>,
    then\ 

    <\equation>
      <label|starlec14>\<up-E\><rsup|\<omega\>><around*|(|\<tau\><rsub|1>|)>=<frac|1|\<omega\><rsub|0>>+<big|sum><rsub|k=1><rsup|+\<infty\>><frac|1|\<omega\><rsub|-k>>\<rho\><rsub|-k+1>\<ldots\>\<rho\><rsub|0>=1+2
      <big|sum><rsub|k=0><rsup|+\<infty\>>\<rho\><rsub|-k>\<rho\><rsub|-k+1>\<ldots\>\<rho\><rsub|0>.
    </equation>
  </lemma>

  <\proof>
    Under the assumption that the following manipulations are ok, that is,
    the following expectations are finite, we have

    <\align>
      <tformat|<table|<row|<cell|\<up-E\><rsub|0><rsup|\<omega\>><around*|(|\<tau\><rsub|1>|)>=>|<cell|\<up-E\><rsub|0><rsup|\<omega\>><around*|(|H<rsub|1>|)>=\<omega\><rsub|0>\<cdot\>1+<around*|(|1-\<omega\><rsub|0>|)><around*|(|1+\<up-E\><rsub|-1><rsup|\<omega\>><around*|(|H<rsub|1>|)>|)>>>|<row|<cell|=>|<cell|1+<around*|(|1-\<omega\><rsub|0>|)><around*|(|\<up-E\><rsub|-1><rsup|\<omega\>><around*|(|H<rsub|0>|)>+\<up-E\><rsub|0><rsup|\<omega\>><around*|(|H<rsub|1>|)>|)>,>>>>
    </align>

    so

    <\equation*>
      \<up-E\><rsub|0><rsup|\<omega\>><around*|[|\<tau\><rsub|1>|]>=<frac|1|\<omega\><rsub|0>>+\<rho\><rsub|0>\<up-E\><rsub|-1><rsup|\<omega\>><around*|[|\<tau\><rsub|0>|]>.
    </equation*>

    Thus iterating the above procedure one obtains that\ 

    <\equation*>
      \<up-E\><rsub|0><rsup|\<omega\>><around*|[|\<tau\><rsub|1>|]>=<frac|1|\<omega\><rsub|0>>+<big|sum><rsub|k=1><rsup|n><frac|1|\<omega\><rsub|-k>>\<rho\><rsub|-k+1>\<ldots\>\<rho\><rsub|0>+\<rho\><rsub|-n>\<ldots\>\<rho\><rsub|0>\<up-E\><rsub|-n-1><rsup|\<omega\>><around*|[|\<tau\><rsub|-n>|]>.
    </equation*>

    For both we truncate. Fix <math|M\<less\>+\<infty\>>. Then,\ 

    <\align>
      <tformat|<table|<row|<cell|\<up-E\><rsub|0><rsup|\<omega\>><around*|[|\<tau\><rsub|1>\<wedge\>M|]>=>|<cell|1+<around*|(|1-\<omega\><rsub|0>|)>\<up-E\><rsub|-1><rsup|\<omega\>><around*|[|<around*|(|1+H<rsub|1>|)>\<wedge\>M|]>>>|<row|<cell|\<leq\>>|<cell|1+<around*|(|1-\<omega\><rsub|0>|)><around*|(|\<up-E\><rsub|-1><rsup|\<omega\>><around*|[|\<tau\><rsub|0>\<wedge\>M|]>+\<up-E\><rsub|0><rsup|\<omega\>><around*|(|\<tau\><rsub|1>\<wedge\>M|)>|)>>>|<row|<cell|\<vdots\>>|<cell|>>|<row|<cell|\<leq\>>|<cell|<frac|1|\<omega\><rsub|0>>+<big|sum><rsub|k=1><rsup|n><frac|1|\<omega\><rsub|-k>>\<rho\><rsub|-k+1>\<ldots\>\<rho\><rsub|0>+\<rho\><rsub|-n>\<ldots\>\<rho\><rsub|0><wide*|\<up-E\><rsub|-n-1><rsup|\<omega\>><around*|[|\<tau\><rsub|-n>\<wedge\>M|]>|\<wide-underbrace\>><rsub|\<leq\>M>.
      >>>>
    </align>

    <with|font-shape|italic|Case 1:> <math|lim<rsub|n\<rightarrow\>+\<infty\>>\<rho\><rsub|-n>\<ldots\>\<rho\><rsub|0>=0>
    which is equivalent to saying that <math|\<bbb-E\><around*|[|log
    \<rho\><rsub|0>|]>\<less\>0>. In this case there is nothing more to do;
    we can just send <math|n\<rightarrow\>+\<infty\>> and then
    <math|M\<rightarrow\>+\<infty\>>. For a lower bound we can just forget
    the last term <math|\<rho\><rsub|-n>\<ldots\>\<rho\><rsub|0>\<up-E\><rsub|-n-1><rsup|\<omega\>><around*|[|\<tau\><rsub|-n>\<wedge\>M|]>>.\ 

    <with|font-shape|italic|Case 2:> If the RHS of <eqref|starlec14> one can
    easily show that <math|\<up-E\><rsub|0><rsup|\<omega\>><around*|(|\<tau\><rsub|1>|)>=+\<infty\>>
    by contradiction, using the above. This concludes the proof.\ 
  </proof>

  <\proof>
    <dueto|Proof of Theorem <reference|12.6>>We only need to verify the
    formula for <math|v>. By Jensen we have\ 

    <\equation*>
      log \<bbb-E\><around*|[|<frac|1|\<rho\><rsub|0>>|]>\<geq\>\<bbb-E\><around*|[|log<frac|1|\<rho\><rsub|0>>|]>=-\<bbb-E\><around*|[|log
      \<rho\><rsub|0>|]>\<geq\><rsup|assumption>0\ 
    </equation*>

    which implies that <math|\<bbb-E\><around*|[|<frac|1|\<rho\><rsub|0>>|]>\<geq\>1>,
    so we only need to very the first two lines in Theorem <eqref|12.6>. By
    <reference|> <todo|12.1> and previous remarks <todo|Finish proof.>
  </proof>

  <\remark>
    <\itemize>
      <item>This law of large numbers also holds without the i.i.d.
      assumption on the environment. Ergodicity is sufficient but the formula
      for <math|v> is less explicit.\ 

      <item>One can prove more results:

      <\itemize>
        <item>averaged CLT: If <math|\<bbb-E\><around*|[|\<rho\><rsub|0><rsup|2>|]>\<less\>1>,
        then <math|<frac|X<rsub|n>-v n|\<sigma\><sqrt|n>><long-arrow|\<rubber-rightarrow\>|\<up-P\>>\<cal-N\><around*|(|0,1|)>>,
        where <math|\<sigma\>> depends on <math|\<bbb-P\>>.\ 

        <item>quenched CLT: If <math|\<bbb-E\><around*|[|\<rho\><rsub|0><rsup|2>|]>\<less\>1>,
        then <math|<frac|X<rsub|n>-v n+Z<rsub|n><around*|(|\<omega\>|)>|n<sqrt|n>><long-arrow|\<rubber-rightarrow\>|\<up-P\><rsup|\<omega\>>>\<cal-N\><around*|(|0,1|)>>.
      </itemize>
    </itemize>
  </remark>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|14.1|<tuple|1|1>>
    <associate|starlec14|<tuple|1|1>>
  </collection>
</references>