<TeXmacs|2.1.1>

<style|<tuple|generic|math-brackets>>

<\body>
  <section|More Ergodic Theory>

  <\definition>
    <label|13.1>A sequence of random variables
    <math|<around*|(|X<rsub|n>|)><rsub|n\<in\>\<bbb-N\>>> of <math|S>-valued
    random variables, where <math|S> is some arbitrary state space is called
    <em|stationary> if for all <math|k\<in\>\<bbb-N\>>,\ 

    <\equation*>
      <around*|(|X<rsub|k+n>|)><rsub|n\<in\>\<bbb-N\><rsub|0>><long-arrow|\<rubber-equal\>|<around*|(|d|)>><around*|(|X<rsub|n>|)><rsub|n\<in\>\<bbb-N\><rsub|0>>
    </equation*>
  </definition>

  The goal is to show that for <math|f:S\<rightarrow\>\<bbb-R\>> such that
  <math|\<up-E\><around*|\||f<around*|(|X<rsub|0>|)>|\|>\<less\>+\<infty\>>
  the value

  <\equation*>
    lim<rsub|n\<rightarrow\>+\<infty\>><frac|1|n><big|sum><rsub|i=0><rsup|n-1>f<around*|(|X<rsub|i>|)><space|1em>
    <text|exists a.s...>
  </equation*>

  <\example>
    <label|13.2>The following sequences are stationary:\ 

    <\enumerate>
      <item><math|<around*|(|X<rsub|n>|)><rsub|n\<geq\>0>> is an i.i.d.
      sequence.\ 

      <item><math|<around*|(|X<rsub|n>|)><rsub|n\<in\>\<bbb-N\><rsub|0>>> - a
      Markov chain wiht transition probability <math|p<around*|(|x,A|)>> and
      stationary distribution <math|\<pi\>>, that is

      <\equation*>
        \<up-P\><around*|(|X<rsub|n+1>\<in\>A\<mid\>X<rsub|n>=x|)>=p<around*|(|x,
        A|)>,<space|1em> <big|int>p<around*|(|x,A|)>\<pi\><around*|(|\<mathd\>x|)>=\<pi\><around*|(|A|)>
      </equation*>

      and <math|X<rsub|0>> is <math|\<pi\>>-distributed (one can show that
      <math|X<rsub|i>\<sim\>\<pi\>> for all <math|i\<in\>\<bbb-N\>>, using
      Markov-property).\ 

      <item><em|Rotations of circle>: Take <math|\<Omega\>=<around*|[|0,1|)>>
      equiped with the Borel <math|\<sigma\>>-algebra and <math|\<up-P\>> the
      Lebesgue measure. Fix <math|\<theta\>\<in\>S> and
      <math|X<rsub|0><around*|(|\<omega\>|)>=\<omega\>\<sim\>\<up-P\>> and

      <\equation*>
        X<rsub|n+1><around*|(|\<omega\>|)>=X<rsub|n><around*|(|\<omega\>|)>+\<theta\><space|1em>
        mod 1
      </equation*>

      This is a Markov chain. It should be intuitively clear why this is is
      stationary.\ 

      <item><math|<with|font-series|bold|1><rsub|<around*|{|k\<cdot\>e<rsub|1><text|
      is a trifurcation>|}>>>.\ 

      <item>The random variables <math|\<tau\><rsub|i>> given by
      (<with|font-series|bold|??>) form a stationary sequence.\ 
    </enumerate>
  </example>

  All the above instances are described by the following: Take
  <math|<around*|(|\<Omega\>,\<cal-A\>,\<up-P\>|)>> a probability space and
  <math|\<varphi\>:\<Omega\>\<rightarrow\>\<Omega\>> measurable and measure
  preserving, that is <math|P<around*|(|\<varphi\><rsup|-1>A|)>=P<around*|(|A|)>>
  for all <math|A\<in\>\<cal-A\>>. Let <math|\<varphi\><rsup|n>=\<varphi\>\<circ\>\<varphi\><rsup|n-1>>
  with <math|\<varphi\><rsup|0>=Id>. Let <math|X> be a random variable. Set\ 

  <\equation>
    X<rsub|n><around*|(|\<omega\>|)>=X<around*|(|\<varphi\><rsup|n><around*|(|\<omega\>|)>|)>.<label|statconstruct>
  </equation>

  <\exercise>
    Show that <math|X<rsub|n>> defined by <eqref|statconstruct> is
    stationary.\ 
  </exercise>

  This encompasses all examples from Example <reference|13.2> by taking
  <math|\<Omega\>=S<rsup|\<bbb-N\><rsub|0>>>,
  <math|\<cal-A\>=\<cal-S\><rsup|\<otimes\>\<bbb-N\><rsub|0>>>,
  <math|\<up-P\>> the law of <math|<around*|(|X<rsub|0>,X<rsub|1>,\<ldots\>|)>>
  where <math|X<rsub|i><around*|(|\<omega\>|)>=\<omega\><rsub|i>> and let
  <math|\<varphi\>> the shift to the left, that is\ 

  <\equation*>
    \<varphi\><around*|(|\<omega\><rsub|0>,\<omega\><rsub|1>,\<ldots\>|)>=<around*|(|\<omega\><rsub|1>,\<omega\><rsub|2>,\<ldots\>|)>
  </equation*>

  <\definition>
    A set <math|A\<in\>\<cal-A\>> is invariant if
    <math|\<up-P\><around*|(|A\<triangle\>\<varphi\><rsup|-1><around*|(|A|)>|)>=0>
    or in slightly sloppy notation: <math|\<varphi\><rsup|-1><around*|(|A|)><long-arrow|\<rubber-equal\>|<text|a.s.>>A>.
    Define\ 

    <\equation*>
      \<cal-I\>\<assign\><around*|{|A\<in\>\<cal-A\>\<mid\><text|<math|A> is
      invariant>|}>,
    </equation*>

    which is a <math|\<sigma\>>-algebra. A function
    <math|f:\<Omega\>\<rightarrow\>\<bbb-R\>> is invariant if
    <math|f\<circ\>\<varphi\>=f> (<math|\<Leftrightarrow\>> <math|f> is
    <math|\<cal-I\>> measurable). The system
    <math|<around*|(|\<Omega\>,\<cal-A\>,\<up-P\>,\<space\>\<varphi\>|)>> is
    called <em|ergodic> if <math|\<cal-I\>> is <math|\<up-P\>>-trivial in the
    sense that <math|\<up-P\><around*|(|A|)>\<in\><around*|{|0,1|}>> for all
    <math|A\<in\>\<cal-I\>>.\ 
  </definition>

  The concepts of ergodicity and irreducibility are related in the sense that
  if <math|\<varphi\>> is not ergodic there exists <math|A> such that
  <math|\<up-P\><around*|(|A|)>\<in\><around*|(|0,1|)>> such that
  <math|\<varphi\><around*|(|A|)>\<subseteq\>A> and
  <math|\<varphi\><around*|(|A<rsup|\<complement\>>|)>\<subseteq\>A<rsup|\<complement\>>>.\ 

  <\example>
    <\itemize>
      <item>Let <math|X> be an i.i.d. sequence, where
      <math|\<Omega\>=S<rsup|\<bbb-N\><rsub|0>>> and <math|\<varphi\>> is the
      shift map. If <math|A> is an invariant set, then
      <math|A\<in\><big|cap><rsub|n\<geq\>0>\<sigma\><around*|(|X<rsub|n>,X<rsub|n+1>,\<ldots\>|)>>
      - the tail <math|\<sigma\>>-algebra so
      <math|<around*|(|\<Omega\>,\<cal-A\>,\<up-P\>,\<varphi\>|)>> is ergodic
      by Kolmogorov's 0-1 law.\ 

      <item>Consider Example <reference|13.2> (3). If
      <math|\<theta\>=<frac|p|q>\<in\>\<bbb-Q\>>, then <math|\<varphi\>> is
      not ergodic because any set <math|<big|cup><rsub|i=0><rsup|q-1>\<varphi\><rsup|i>A>
      is invariant. If <math|\<theta\>> is irrational, then <math|\<varphi\>>
      is ergodic.
    </itemize>
  </example>

  <\exercise>
    Prove that the Markov-chain from Example <reference|13.2> is ergodic iff
    its irreducible.\ 
  </exercise>

  <\theorem>
    <dueto|Birkhoff's pointwise Ergodic Theorem, 1931><label|13.7>If
    <math|<around*|(|\<Omega\>,\<cal-A\>,\<up-P\>,\<varphi\>|)>> is a measure
    preserving system (that is, <math|\<varphi\>> is measure preserving) and
    <math|X:\<Omega\>\<rightarrow\>\<bbb-R\>> is in
    <math|L<rsup|1><around*|(|\<up-P\>|)>>. Then

    <\equation*>
      <frac|1|n><big|sum><rsub|i=0><rsup|n-1>f<around*|(|<around*|(|X\<circ\>\<varphi\><rsup|n>|)><around*|(|\<omega\>|)>|)><below|<long-arrow|\<rubber-rightarrow\>|<text|a.s.>,L<rsup|1>>|n\<rightarrow\>+\<infty\>>\<up-E\><around*|[|X\<mid\>\<cal-I\>|]><around*|(|\<omega\>|)>.
    </equation*>
  </theorem>

  <\remark>
    <\itemize>
      <item>Note that if the system <math|<around*|(|\<Omega\>,\<cal-A\>,\<up-P\>,\<varphi\>|)>>
      is ergodic, then <math|\<up-E\><around*|[|X\<mid\>\<cal-I\>|]>=\<up-E\><around*|[|X|]>>
      a.s.. This means that this result implies the strong law of large
      numbers.\ 

      <item>If <math|<around*|(|X<rsub|n>|)><rsub|n\<in\>\<bbb-N\><rsub|0>>>
      is an irreducible Markov-chain started form <math|\<pi\>> and
      <math|f\<in\>L<rsup|1><around*|(|\<pi\>|)>>, then this theorem implies
      that\ 

      <\equation*>
        <frac|1|n><big|sum><rsub|i=1><rsup|n>f<around*|(|X<rsub|i>|)><long-arrow|\<rubber-rightarrow\>||n\<rightarrow\>+\<infty\>><big|int><rsub|S>f<around*|(|x|)>\<mathd\>\<pi\><around*|(|x|)>.
      </equation*>

      <item>If <math|\<theta\>> is irrational and
      <math|f=<with|font-series|bold|1><rsub|A>> then

      <\equation*>
        <frac|1|n><big|sum><rsub|k=1><rsup|n><with|font-series|bold|1><rsub|A><around*|(|<around*|(|\<omega\>+k\<theta\>|)>mod
        1|)><below|<long-arrow|\<rubber-rightarrow\>|a.s.,L<rsup|1>>|n\<rightarrow\>+\<infty\>>\<up-P\><around*|(|A|)>
      </equation*>

      this is similar to Weyl's equidistribution theorem.\ 
    </itemize>
  </remark>

  <\proof>
    <dueto|Not done in the lecture!>see Peterson 2000 (very simple proof of
    ergodic theorem, see Adam).\ 
  </proof>

  <\definition>
    The measure preserving map <math|\<varphi\>> is <em|strongly mixing> if
    for any <math|A,B\<in\>\<cal-A\>>

    <\equation*>
      lim<rsub|n\<rightarrow\>+\<infty\>>\<up-P\><around*|(|A\<cap\>\<varphi\><rsup|-n><around*|(|B|)>|)>=\<up-P\><around*|(|A|)>\<up-P\><around*|(|B|)>.
    </equation*>
  </definition>

  Analoguous to the proof of Theorem <reference|4.4> we get the following:\ 

  <\theorem>
    If <math|\<varphi\>> is strongly mixing, then
    <math|<around*|(|\<Omega\>,\<cal-A\>,\<up-P\>,\<varphi\>|)>> is ergodic.\ 
  </theorem>

  <\lemma>
    <label|13.10>If <math|limsup<rsub|n\<rightarrow\>+\<infty\>>X<rsub|n>=+\<infty\>>
    <math|\<up-P\>>-a.s., that is if <math|\<bbb-E\><around*|[|log
    \<rho\><rsub|0>|]>\<leq\>0> then <math|<around*|(|\<tau\><rsub|i>|)><rsub|i\<geq\>1>>
    is a stationary strong mixing (and thus ergodic system) under
    <math|\<up-P\>=\<up-P\><rsub|0>> (the anihiled measure). \ 
  </lemma>

  <\proof>
    The <em|stationarity> follows directly from the stationarity of the
    random environment (<math|\<omega\>> is i.i.d.) and the Markov-property
    under <math|\<up-P\><rsup|\<omega\>>>.\ 

    We now show <em|strong mixing>: To this end, we start with \Pcylinder
    events\Q,\ 

    <\equation*>
      A=<big|cap><rsub|i=1><rsup|k><around*|{|\<tau\><rsub|i>\<in\>A<rsub|i>|}>,<space|1em>
      B=<big|cap><rsub|i=1><rsup|\<ell\>><around*|{|\<tau\><rsub|i>\<in\>B<rsub|i>|}>,<space|1em>
      A<rsub|i>,B<rsub|i>\<subseteq\>\<bbb-N\>.
    </equation*>

    We know that <math|limsup X<rsub|n>=+\<infty\>> so
    <math|\<up-P\><around*|(|\<tau\><rsub|i>\<gtr\>M|)>\<searrow\>0> as
    <math|M\<nearrow\>+\<infty\>>. So for given <math|\<varepsilon\>\<gtr\>0>
    we can fix <math|M=M<around*|(|\<varepsilon\>|)>> such that\ 

    <\equation*>
      B<rsup|m,M>=<big|cap><rsub|i=1><rsup|\<ell\>><around*|{|\<tau\><rsub|i+m>\<in\>B<rsup|M><rsub|i>|}>,<space|1em>
      <text|where <math|B<rsub|i><rsup|M>\<assign\>B<rsub|i>\<cap\><around*|[|0,M|]>>>
    </equation*>

    satisfies <math|\<up-P\><around*|(|B<rsup|n>\<setminus\>B<rsup|m,M><rsup|>|)>\<leq\>\<varepsilon\>>.
    One has that <math|B<rsup|m,M>> depends on
    <math|\<omega\><rsub|m-M>,\<ldots\>,\<omega\><rsub|m+\<ell\>-1>> whereas
    <math|A> depends only on <math|\<omega\><rsub|k-1>,\<omega\><rsub|k-2>,\<ldots\><rsub|>>
    i.e., for <math|m\<geq\>M+k> the events <math|B<rsup|m,M>> and <math|A>
    depend on different <math|\<omega\><rsub|i>>'s. Since we choose
    <math|\<omega\><rsub|i>> to be i.i.d. we have that <math|B<rsup|m,M>> and
    <math|A> are then idependent i.e.,\ 

    <\equation*>
      \<up-P\><around*|(|A\<cap\>B<rsup|m,M>|)>=\<up-P\><around*|(|A|)>\<up-P\><around*|(|B<rsup|m,M>|)>=\<up-P\><around*|(|A|)>\<up-P\><around*|(|B<rsup|0,M>|)>
    </equation*>

    this implies the lemma for cylindrical events. By lemma <reference|4.3>
    (<with|font-series|bold|??>) any event can be approximated by cylinders
    which implies the strong mixing.\ 
  </proof>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|13.1|<tuple|1|1|../.TeXmacs/texts/scratch/no_name_8.tm>>
    <associate|13.10|<tuple|9|2|../.TeXmacs/texts/scratch/no_name_8.tm>>
    <associate|13.2|<tuple|2|1|../.TeXmacs/texts/scratch/no_name_8.tm>>
    <associate|13.7|<tuple|5|2|../.TeXmacs/texts/scratch/no_name_8.tm>>
    <associate|auto-1|<tuple|1|1|../.TeXmacs/texts/scratch/no_name_8.tm>>
    <associate|statconstruct|<tuple|1|1|../.TeXmacs/texts/scratch/no_name_8.tm>>
  </collection>
</references>

<\auxiliary>
  <\collection>
    <\associate|toc>
      <vspace*|1fn><with|font-series|<quote|bold>|math-font-series|<quote|bold>|1<space|2spc>More
      Ergodic Theory> <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-1><vspace|0.5fn>
    </associate>
  </collection>
</auxiliary>