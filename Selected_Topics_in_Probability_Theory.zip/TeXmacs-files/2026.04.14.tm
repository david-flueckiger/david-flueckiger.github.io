<TeXmacs|2.1.4>

<style|generic>

<\body>
  <subsection|Sinai's model: non standard limit laws>

  We now want to understand the situation when <math|X> is recurrent. Note
  that this section is about very advanced maths thus it will be higher level
  than usual in this lecture.\ 

  <with|font-series|bold|Assumption> We assume that
  <math|\<bbb-E\><around*|[|log \<rho\><rsub|0>|]>=0>, <math|><eqref|(UE)>,
  i.e., <math|log \<rho\><rsub|0>> is bounded and that
  <math|<around*|(|\<omega\><rsub|x>|)><rsub|x\<in\>\<bbb-Z\>>> is an i.i.d.
  sequence of random variables.\ 

  Recall that the harmonic function <math|f> given by <eqref|falternate>.
  Here <math|V<around*|(|x|)>> is a sum of centered i.i.d. random variable,
  so one can use Donsker's theorem to understand its behaviour.

  <\lemma>
    <todo|Should be a claim>Let\ 

    <\equation*>
      W<rsup|n><around*|(|t|)>=<frac|1|log n>V<around*|(|\<lfloor\>t log
      <rsup|2> n\<rfloor\>|)>,<space|1em> t\<in\>\<bbb-R\>.
    </equation*>

    Then\ 

    <\equation*>
      <around*|(|W<rsup|n><around*|(|t|)>|)><rsub|t\<in\>\<bbb-R\>><long-arrow|\<rubber-rightarrow\>|<rsup|d>><around*|(|\<sigma\>
      B<rsub|t>|)><rsub|t\<in\>\<bbb-R\>>
    </equation*>

    where <math|\<sigma\>=\<bbb-E\><around*|[|log<around*|(|\<rho\><rsub|0>|)><rsup|2>|]>>
    and <math|<around*|(|B<rsub|t>|)><rsub|t\<in\>\<bbb-R\>>> is a two sided
    Brownian motion, that is <math|<around*|(|B<rsub|t>|)><rsub|t\<geq\>0>>
    and <math|<around*|(|B<rsub|-t>|)><rsub|t\<geq\>0>> are two independent
    Brownian motion.\ 
  </lemma>

  <\proof>
    Use Donsker's theorem.\ 
  </proof>

  <\remark>
    <label|15.3>The role of the potential <math|V> is more visible when one
    studies the invariant measures of <math|X> under
    <math|\<up-P\><rsup|\<omega\>>>.\ 
  </remark>

  From the exercises we know that if the measure is invariant, then <math|X>
  is reversible. That is, there exists some function
  <math|\<pi\>:\<bbb-Z\>\<rightarrow\><around*|[|0,+\<infty\>|)>> such that
  <math|\<pi\><around*|(|x|)>\<omega\><rsub|x>=\<pi\><around*|(|x+1|)><around*|(|1-\<omega\><rsub|x+1>|)>>.
  Setting <math|\<pi\><around*|(|0|)>=1> we get by iterating

  <\align>
    <tformat|<table|<row|<cell|\<pi\><around*|(|x|)>>|<cell|=<choice|<tformat|<table|<row|<cell|<big|prod><rsub|i=0><rsup|x-1><frac|\<omega\><rsub|i>|1-\<omega\><rsub|i+1>>,>|<cell|x\<gtr\>0>>|<row|<cell|1,>|<cell|x=0>>|<row|<cell|<big|prod><rsub|i=x><rsup|-1><frac|1-\<omega\><rsub|i+1>|\<omega\><rsub|i>>,>|<cell|x\<less\>0>>>>>>>|<row|<cell|>|<cell|=<choice|<tformat|<table|<row|<cell|<frac|1-\<omega\><rsub|0>|1-\<omega\><rsub|x>>\<cdot\><big|prod><rsub|i=0><rsup|x-1><frac|1|\<rho\><rsub|i>>=<frac|1-\<omega\><rsub|0>|1-\<omega\><rsub|x>>\<mathe\><rsup|-V<around*|(|x|)>>,>|<cell|x\<gtr\>0>>|<row|<cell|1,>|<cell|x=0>>|<row|<cell|<frac|1-\<omega\><rsub|0>|1-\<omega\><rsub|x>><big|prod><rsub|i=x><rsup|-1>\<rho\><rsub|i>=<wide*|<frac|1-\<omega\><rsub|0>|1-\<omega\><rsub|x>>|\<wide-underbrace\>><rsub|bounded>\<mathe\><rsup|-V<around*|(|x|)>>,>|<cell|x\<less\>0>>>>>.>>>>
  </align>

  Imagine now that we restrict our random walk <math|X> to the interval
  <math|<around*|[|-N,N|]>> by setting <math|\<omega\><rsub|N>=0>,
  <math|\<omega\><rsub|-N>=1>.

  <todo|Bild 26>

  If <math|x\<nin\>J> then <math|<frac|\<pi\><around*|(|x|)>|\<pi\><around*|(|min|)>><code*|>=<cong><frac|\<mathe\><rsup|-V<around*|(|x|)>>|\<mathe\><rsup|-V<around*|(|min|)>>>\<asymp\>\<mathe\><rsup|-\<varepsilon\><sqrt|N>>>,
  thus\ 

  <\equation*>
    <frac|\<pi\><around*|(|J<rsup|\<complement\>>|)>|\<pi\><around*|(|J|)>>\<leqslant\>2N\<mathe\><rsup|-\<varepsilon\><sqrt|N>><long-arrow|\<rubber-rightarrow\>|<rsup|N\<rightarrow\>+\<infty\>>>0,
  </equation*>

  hence <math|\<pi\>> is very far from being a unform distribution, that is
  <math|X> spends most of its time in <math|J>.\ 

  <\definition>
    <label|15.4>A triple <math|<around*|(|a,b,c|)>> with
    <math|a\<less\>b\<less\>c> is a <em|valley> of <math|W<rsup|n>> if
    <math|W<rsup|n><around*|(|b|)>=min<rsub|a\<leq\>t\<leqslant\>c>W<rsup|n><around*|(|t|)>>
    and

    <\equation*>
      W<rsup|n><around*|(|a|)>=max<rsub|a\<leqslant\>t\<leqslant\>b>W<rsup|n><around*|(|t|)><space|1em>
      <text|and><space|1em> W<rsup|n><around*|(|c|)>=max<rsub|b\<leqslant\>t\<leqslant\>c>W<rsup|n><around*|(|t|)>.
    </equation*>

    We denote the <em|depth> of the valley by

    <\equation*>
      d<around*|(|a,b,c|)>=min<around*|{|W<rsup|n><around*|(|a|)>-W<rsup|n><around*|(|b|)>,W<rsup|n><around*|(|c|)>-W<rsup|n><around*|(|b|)>|}>.
    </equation*>

    If <math|a\<less\>d\<less\>e\<less\>b> are such that

    <\equation*>
      W<rsup|n><around*|(|e|)>-W<rsup|n><around*|(|d|)>=max<rsub|a\<leqslant\>x\<less\>y\<leqslant\>b>W<rsup|n><around*|(|y|)>-W<rsup|n><around*|(|x|)>
    </equation*>

    (the maximal increase), then <math|<around*|(|a,d,e|)>> and
    <math|<around*|(|e,b,c|)>> are again valleys. This procedure is called
    <em|left refinement> of <math|<around*|(|a,b,c|)>>. \ <todo|Bild 27>.
    <em|Right refinement> is defined analoguously.\ 
  </definition>

  By left/right refinement one splits the valey in two new valleys. We now
  construct a very \Pspecific\Q valley. Let\ 

  <\align>
    <tformat|<table|<row|<cell|c<rsub|0><rsup|n>>|<cell|=min<around*|{|t\<geq\>0:W<rsup|n><around*|(|t|)>\<geq\>1|}>>>|<row|<cell|a<rsub|0><rsup|n>>|<cell|=max<around*|{|t\<less\>0:W<rsup|n><around*|(|t|)>\<geq\>1|}>>>|<row|<cell|b<rsub|0><rsup|n>>|<cell|=<text|the
    position of the global minimum of <math|W<rsup|n>> in
    <math|<around*|[|a<rsub|0><rsup|n>,c<rsub|0><rsup|n>|]>>>.>>>>
  </align>

  Note that <math|b<rsub|0><rsup|n>> is not well defined as there might be
  multiple minima. However with probability tending to 1 as
  <math|n\<rightarrow\>+\<infty\>> there is only one minimum, so we will
  ignore this case. By refining this valley one can construct the
  \Psmallest\Q valley <math|<around*|(|a<rsub|n><rsup|\<delta\>>,b<rsub|n><rsup|\<delta\>>,c<rsub|n><rsup|\<delta\>>|)>>
  such that <math|d<around*|(|a<rsub|n>,b<rsub|n>,c<rsub|n>|)>\<geq\>1+\<delta\>>
  and the origin is contained in the valley.

  <\theorem>
    <dueto|Sinai, 1982><label|15.5>It holds that

    <\equation*>
      <frac|X<rsub|n>|log<rsup|2>n>-b<rsub|n><below|<long-arrow|\<rubber-rightarrow\>|\<up-P\><rsub|0>>|n\<rightarrow\>+\<infty\>>0.
    </equation*>
  </theorem>

  <\remark>
    <\itemize>
      <item>As <math|b<rsub|n>> is of order 1, typically, this implies that
      <math|<around*|\||X<rsub|n>|\|>\<approx\>log<rsup|2>n>. Compare it with
      the usual symmetric random walk with
      <math|<around*|\||X<rsub|n>|\|>\<approx\><sqrt|n>>.\ 

      <item>Definition <reference|15.4> implies that given <math|\<omega\>>,
      <math|X<rsub|n>> is \Pessentially deterministic\Q and located (with
      high probability) at <math|b<rsub|n>\<cdot\>log<rsup|2>n+
      o<around*|(|log<rsup|2>n|)>>.\ 
    </itemize>
  </remark>

  <\proof>
    We will only sketch the proof as it is quite long.\ 

    <with|font-shape|italic|Step 1: <math|<around*|(|a<rsub|n>,b<rsub|n>,c<rsub|n>|)>>
    is with high probability (w.h.p.) non-degenerate>. Let
    <math|A<rsub|n><rsup|J,\<delta\>>> be the collection of all
    <math|\<omega\>\<in\>\<Omega\>> such that

    <\itemize>
      <item><math|b<rsub|n>=b<rsub|n><rsup|\<delta\>>>

      <item>any refinement of <math|<around*|(|a<rsub|n><rsup|\<delta\>>,b<rsub|n><rsup|\<delta\>>,c<rsub|n><rsup|\<delta\>>|)>>
      has depth <math|\<less\>1-\<delta\>>.\ 

      <item><math|<around*|\||a<rsub|n><rsup|\<delta\>>|\|>+<around*|\||c<rsub|n><rsup|\<delta\>>|\|>\<less\>J>
      and

      <item>we have

      <\equation*>
        min<rsub|t\<in\><around*|[|a<rsub|n>,c<rsub|n>|]>\<setminus\><around*|[|b<rsub|n>-\<delta\>,b<rsub|n>+\<delta\>|]>>W<rsup|n><around*|(|t|)>-W<rsup|n><around*|(|b<rsub|n>|)>\<geq\>\<delta\><rsup|3>.
      </equation*>
    </itemize>

    Using the properties of Brownian motion one checks that

    <\equation*>
      lim<rsub|\<delta\>\<searrow\>0>lim<rsub|J\<rightarrow\>+\<infty\>>lim<rsub|n\<rightarrow\>+\<infty\>>\<up-P\><around*|(|A<rsub|n><rsup|J,\<delta\>>|)>=1.
    </equation*>

    This shows the first step.\ 

    For simplicity from now on we assume that
    <math|A<rsub|n><rsup|J,\<delta\>>> holds and <math|b<rsub|n>\<geq\>0>.
    <todo|Bild 28> We set <math|A<rsub|n><rsup|\<delta\>>=\<lfloor\><around*|(|log<rsup|2>n|)>a<rsub|n><rsup|\<delta\>>\<rfloor\>>,
    <math|B<rsub|n><rsup|\<delta\>>=\<lfloor\><around*|(|log<rsup|2>n|)>b<rsub|n><rsup|\<delta\>>\<rfloor\>>,
    <math|C<rsub|n><rsup|\<delta\>>=\<lfloor\><around*|(|log<rsup|2>n|)>c<rsub|n><rsup|\<delta\>>\<rfloor\>>.

    <\with|font-shape|italic>
      Step 2: <math|\<up-P\><rsup|\<omega\>><rsub|0><around*|[|H<rsub|B<rsub|n>>\<leq\>n|]><long-arrow|\<rubber-rightarrow\>|<rsup|n\<rightarrow\>+\<infty\>>>1>.
    </with>

    \ Since <math|f> is harmonic, we have\ 

    <\equation*>
      \<up-P\><rsup|\<omega\>><rsub|0><around*|(|H<rsub|A<rsub|n><rsup|\<delta\>>>\<leq\>H<rsub|B<rsub|n>>|)>=<frac|f<around*|(|B<rsub|n>|)>-f<around*|(|0|)>|f<around*|(|B<rsub|n>|)>-f<around*|(|A<rsub|n><rsup|\<delta\>>|)>>=<frac|<big|sum><rsub|x=1><rsup|B<rsub|n>>\<mathe\><rsup|V<around*|(|x|)>>|<big|sum><rsub|x=A+1><rsup|B<rsub|n>>\<mathe\><rsup|V<around*|(|x|)>>>.
    </equation*>

    Due to the second property of <math|A<rsub|n><rsup|J,\<delta\>>> the sum
    in the denominator contains a term <math|\<mathe\><rsup|V<around*|(|x<rsub|0>|)>>>
    such that <math|V<around*|(|x<rsub|0>|)>\<geq\>\<delta\>
    log<around*|(|n|)>+V<around*|(|y|)>> for all
    <math|y\<in\><around*|[|1,B<rsub|n>|]>>. Hence\ 

    <\equation>
      <label|lec15,1>\<up-P\><rsup|\<omega\>><rsub|0><around*|(|H<rsub|A<rsub|n><rsup|\<delta\>>>\<leq\>H<rsub|B<rsub|n>>|)>\<leq\><frac|<wide|<around*|\||B<rsub|n>|\|>|\<wide-overbrace\>><rsup|\<leq\>J
      log<rsup|2>n>max<rsub|y\<in\><around*|[|1,B<rsub|n>|]>>\<mathe\><rsup|V<around*|(|y|)>>|\<mathe\><rsup|V<around*|(|x<rsub|0>|)>>>\<leq\>J
      log<rsup|2><around*|(|n|)>\<mathe\><rsup|-\<delta\>log
      n>\<leq\><around*|(|J log<rsup|2>n|)>n<rsup|-\<delta\>><long-arrow|\<rubber-rightarrow\>|<rsup|n\<rightarrow\>+\<infty\>>>0.
    </equation>

    Consider now RWRE \Preflected at <math|A<rsub|n><rsup|\<delta\>>>\Q. Then
    as in Lemma <reference|14.1>,\ 

    <\equation*>
      \<up-E\><rsup|\<omega\>><rsub|0><around*|[|\<tau\><rsub|1>|]>=<frac|1|\<omega\><rsub|0>>+\<cdots\>+<frac|1|\<omega\><rsub|A<rsub|n><rsup|\<delta\>>+1>>\<rho\><rsub|A<rsub|n><rsup|\<delta\>>+2>\<ldots\>\<rho\><rsub|0>+\<rho\><rsub|A<rsub|n><rsup|\<delta\>>+1>\<ldots\>\<rho\><rsub|0>.
      </equation*>

    Since the reflection does not change the law of
    <math|H<rsub|<around*|{|A<rsub|n><rsup|\<delta\>>,B-n|}>>\<assign\><wide|H<rsub|n>|\<bar\>>>,\ 

    <\align>
      <tformat|<table|<row|<cell|\<up-E\><rsub|0><rsup|\<omega\>><around*|[|<wide|H<rsub|n>|\<bar\>>|]>=>|<cell|<wide|<wide|\<up-E\><rsup|\<omega\>><rsub|0>|~>|\<wide-overbrace\>><rsup|<text|reflection>><around*|[|<wide|H<rsub|n>|\<bar\>>|]>\<leq\><wide|\<up-E\><rsup|\<omega\>><rsub|0>|~><around*|[|H<rsub|B<rsub|n>>|]>=<wide|\<up-E\><rsup|\<omega\>><rsub|0>|~><around*|[|<big|sum><rsub|i=1><rsup|B<rsub|n>>\<tau\><rsub|i>|]>>>|<row|<cell|=>|<cell|<big|sum><rsub|i=1><rsup|B<rsub|n>><big|sum><rsub|x=A<rsub|n><rsup|\<delta\>>><rsup|i-1><wide*|<frac|1|\<omega\><rsub|x>>|\<wide-underbrace\>><rsub|\<leq\>c><wide*|\<rho\><rsub|x+1>\<ldots\>\<rho\><rsub|i-1>|\<wide-underbrace\>><rsub|\<mathe\><rsup|V<around*|(|i|)>-V<around*|(|x|)>>>>>|<row|<cell|\<leq\>>|<cell|c
      <big|sum><rsub|i=1><rsup|B<rsub|n>><big|sum><rsub|x=A<rsub|n><rsup|\<delta\>>><rsup|i-1>\<mathe\><rsup|log
      n <around*|(|W<rsup|n><around*|(|<frac|i|log<rsup|2>n>|)>-W<rsup|n><around*|(|<frac|x|log<rsup|2>n>|)>|)>>>>|<row|<cell|\<leq\>>|<cell|C
      <around*|(|J log<rsup|2>n|)><rsup|2>
      n<rsup|<around*|(|1-\<delta\>|)>>\<leq\>n<rsup|1-<frac|\<delta\>|2>>,>>>>
    </align>

    where we used that <math|><math|W<rsup|n><around*|(|<frac|i|log<rsup|2>n>|)>-W<rsup|n><around*|(|<frac|x|log<rsup|2>n>|)>\<leq\>1-\<delta\>>
    due to the second property of <math|A<rsub|n><rsup|J,\<delta\>>>. By
    Markov,\ 

    <\equation>
      <label|lec15,2>\<up-P\><around*|(|<wide|H<rsub|n>|\<bar\>>\<gtr\>n|)><long-arrow|\<rubber-rightarrow\>||n\<rightarrow\>+\<infty\>>0,
    </equation>

    hence combining <eqref|lec15,1> and <eqref|lec15,2> one deduces\ 

    <\equation*>
      \<up-P\><around*|(|<wide|H<rsub|n>|\<bar\>>\<less\>n,X<rsub|H<rsub|n>>=B<rsub|n>|)><long-arrow|\<rubber-rightarrow\>||n\<rightarrow\>+\<infty\>>1,
    </equation*>

    proving the claim.\ 

    <with|font-shape|italic|Step 3> Similarly to the proof of <eqref|lec15,1>
    one proves

    <\align>
      <tformat|<table|<row|<cell|\<up-P\><rsup|\<omega\>><rsub|B<rsub|n>-1><around*|[|H<rsub|B<rsub|n>>\<less\>H<rsub|A<rsub|n><rsup|\<delta\>>>|]>\<geq\>>|<cell|1-n<rsup|-<around*|(|1+<frac|\<delta\>|2>|)>>,>>|<row|<cell|\<up-P\><rsup|\<omega\>><rsub|B<rsub|n>+1><around*|[|H<rsub|B<rsub|n>>\<less\>H<rsub|C<rsub|n><rsup|\<delta\>>>|]>\<geq\>>|<cell|1-n<rsup|-<around*|(|1+<frac|\<delta\>|2>|)>>.>>>>
    </align>

    We ommit this proof here.\ 

    Steps 2 and 3 imply that on <math|A<rsub|n><rsup|J,\<delta\>>> with high
    probability,\ 

    <\itemize>
      <item><math|X> reaches <math|B<rsub|n>> before time <math|n>

      <item>After reaching <math|B<rsub|n>>, <math|X> will need at least
      <math|n<rsup|1+<frac|\<delta\>|2>>> steps to exit
      <math|<around*|[|A<rsub|n><rsup|\<delta\>>,C<rsub|n><rsup|\<delta\>>|]>>.
      </itemize>

    So instead of looking at <math|X> we may look at its reversion that is
    refelcted at <math|A<rsub|n><rsup|\<delta\>>> and
    <math|C<rsub|n><rsup|\<delta\>>> (i.e.,
    <math|\<omega\><rsub|A<rsub|n><rsup|\<delta\>>>=1> and
    <math|\<omega\><rsub|C<rsub|n><rsup|\<delta\>>>=0>). We use
    <math|<wide|\<up-E\>|~><rsup|\<omega\>>,<wide|\<up-P\>|~><rsup|\<omega\>>>
    for this reversion. Its advantage is that it is a \Pfinite state space\Q
    Markov chain, which is reversible.\ 
  </proof>

  <todo|Bei 0:33 stehengeblieben.>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|15.3|<tuple|2|1>>
    <associate|15.4|<tuple|3|2>>
    <associate|15.5|<tuple|4|2>>
    <associate|auto-1|<tuple|1|1>>
    <associate|lec15,1|<tuple|1|?>>
    <associate|lec15,2|<tuple|2|?>>
  </collection>
</references>

<\auxiliary>
  <\collection>
    <\associate|toc>
      <with|par-left|<quote|1tab>|1<space|2spc>Sinai's model: non standard
      limit laws <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-1>>
    </associate>
  </collection>
</auxiliary>