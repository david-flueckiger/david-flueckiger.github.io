<TeXmacs|2.1.1>

<style|generic>

<\body>
  Note: This section is based on the lecture notes of Barlow; see ADAM.\ 

  <chapter|Random walks and electrical resistance>

  <\todo>
    Bild 29
  </todo>

  <paragraph|Electrical Current>We have Ohm's law, that is there exists some
  <math|U:V\<rightarrow\>\<bbb-R\>> such that for any <math|x,y>, the
  resistance of <math|<around*|{|x,y|}>> is given by

  <\equation*>
    U<around*|(|y|)>-U<around*|(|x|)>=<frac|I<rsub|x,y>|\<mu\><rsub|x,y>>
  </equation*>

  (by reversing the electrical flow, replacing <math|I<rsub|x,y>> with
  <math|-I<rsub|x,y>> is possible, this is just a convention). We further
  assume Kirchhoff's law (marked with '!'),\ 

  <\equation*>
    <big|sum><rsub|y\<in\>V>I<rsub|x,y>=<big|sum><rsub|x\<sim\>y>I<rsub|x,y><long-arrow|\<rubber-equal\>|!>0<space|1em>
    <text|for all <math|x\<nin\><around*|{|x<rsub|1>,x<rsub|0>|}>>><with|font-series|bold|>.
  </equation*>

  Note that Ohm's law gives\ 

  <\equation*>
    0=<big|sum><rsub|y>I<rsub|x,y><long-arrow|\<rubber-equal\>|<text|Ohm>><big|sum><rsub|y>\<mu\><rsub|x,y><around*|(|U<around*|(|y|)>-U<around*|(|x|)>|)>=\<pi\><around*|(|x|)>\<Delta\>U<around*|(|x|)>,
  </equation*>

  i.e., <math|U> is harmonic. We want to solve the following discrete
  <em|Dirichlet problem>:\ 

  <\equation>
    <label|DP><choice|<tformat|<table|<row|<cell|\<Delta\>U<around*|(|x|)>>|<cell|=>|<cell|0>|<cell|<text|on
    <math|<around*|{|x<rsub|0>,x<rsub|1>|}><rsup|\<complement\>>>>>>|<row|<cell|U<around*|(|x<rsub|0>|)>>|<cell|=>|<cell|0,>|<cell|U<around*|(|x<rsub|1>|)>=1>>>>>.
  </equation>

  <\lemma>
    <label|15.1>If the graph <math|G> is finite, <eqref|DP> has a unique
    solution given by\ 

    <\equation*>
      U<around*|(|x|)>=\<up-P\><rsub|x><around*|(|H<rsub|x<rsub|1>>\<less\>H<rsub|x<rsub|0>>|)>.
    </equation*>
  </lemma>

  <\remark>
    By finiteness of <math|G> one could use linear algebra to prove this. We
    will, however, use a different proof.\ 
  </remark>

  <\proof>
    Set <math|\<varphi\><around*|(|x|)>=\<up-P\><rsub|x><around*|(|H<rsub|x<rsub|1>>\<less\>H<rsub|x<rsub|0>>|)>>.
    Then <math|\<varphi\><around*|(|x<rsub|i>|)>=i> for <math|i=0,1>. Also by
    (<with|font-series|bold|??>) we have that <math|\<varphi\>> is harmonic
    on <math|<around*|{|x<rsub|1>,x<rsub|0>|}><rsup|\<complement\>><rsup|>>.
    Suppose that <math|U<rsub|1>,U<rsub|2>> are solutions to <eqref|DP>. Then
    <math|u=U<rsub|1>-U<rsub|2>> satisfies <eqref|DP> with homogenous
    boundary conditions. Using discrete Green Gauss (Theorem
    (<with|font-series|bold|??>), which we can use because we are on a
    <em|finite> graph) we have\ 

    <\align>
      <tformat|<table|<row|<cell|\<cal-E\><around*|(|u,u|)>=>|<cell|-<around|\<langle\>|u,\<Delta\>u|\<rangle\>>=<big|sum><rsub|x\<in\>V>\<pi\><around*|(|x|)>u<around*|(|x|)>\<Delta\>u<around*|(|x|)>>>|<row|<cell|=>|<cell|<big|sum><rsub|x\<in\>V\<setminus\><around*|{|x<rsub|0>,x<rsub|1>|}>>\<pi\><around*|(|x|)>u<around*|(|x|)>\<Delta\>u<around*|(|x|)>+<big|sum><rsub|x\<in\><around*|{|x<rsub|0>,x<rsub|1>|}>>\<pi\><around*|(|x|)>u<around*|(|x|)>\<Delta\>u<around*|(|x|)>>>|<row|<cell|=>|<cell|0,>>>>
    </align>

    which implies that <math|u> is constant. Using the initial condition
    <math|u<around*|(|x<rsub|0>|)>=0> we obtain <math|u\<equiv\>0>.\ 
  </proof>

  <\remark>
    If <math|<around*|(|G,\<mu\>|)>> is transient, the function

    <\equation*>
      h<rsup|B><around*|(|x|)>=\<up-P\><rsub|x><around*|(|H<rsub|B>=+\<infty\>|)><neg|\<equiv\>>0,<space|1em>
      <text|where <math|B=<around*|{|x<rsub|0>,x<rsub|1>|}>>.>
    </equation*>

    Also <math|h<rsup|B>> is harmonic on <math|B<rsup|\<complement\>>> and
    <math|h<rsup|B><around*|(|x<rsub|0>|)>=h<rsup|B><around*|(|x<rsub|1>|)>=0>,
    that is <math|\<varphi\>+\<lambda\>h<rsup|B>> solves <eqref|DP> for all
    <math|\<lambda\>\<in\>\<bbb-R\>>, so we cannot guarantee the uniqueness
    of a solution of <eqref|DP>.\ 
  </remark>

  <\definition>
    Define

    <\equation*>
      F<around*|(|I,x<rsub|0>|)>\<assign\><big|sum><rsub|y\<sim\>x<rsub|0>>I<rsub|x<rsub|0>,y>=<big|sum><rsub|y\<in\>V>I<rsub|x<rsub|0>,y>
    </equation*>

    the <em|total current from <math|x<rsub|0>>>. This is also the total
    current in the circuit. Also define the <em|effective resistance between
    <math|x<rsub|0>> and <math|x<rsub|1>>> by

    <\equation*>
      R<rsub|eff><around*|(|x<rsub|0>,x<rsub|1>|)>=R<around*|(|x<rsub|0>,x<rsub|1>|)>=<frac|U|I>=<frac|1|F<around*|(|I,x<rsub|0>|)>>
    </equation*>

    and\ 

    <\equation*>
      C<rsub|eff><around*|(|x<rsub|0>,x<rsub|1>|)>=C<around*|(|x<rsub|0>,x<rsub|1>|)>=<frac|1|R<rsub|eff><around*|(|x<rsub|0>,x<rsub|1>|)>>=F<around*|(|I,x<rsub|0>|)>.
    </equation*>
  </definition>

  <\exercise>
    <\itemize>
      <item>Prove that if <math|G> is finite
      <math|F<around*|(|I,x<rsub|0>|)>=-F<around*|(|I,x<rsub|1>|)>>.\ 

      <item>Show that <math|R<rsub|eff><around*|(|x<rsub|0>,x<rsub|1>|)>=R<rsub|eff><around*|(|x<rsub|1>,x<rsub|0>|)>>
      that is resistance is independent of direction (obivous from a physical
      perspective).\ 
    </itemize>
  </exercise>

  <\theorem>
    <label|18.4>Suppose that <math|G> is finite. For any
    <math|x<rsub|0>,x<rsub|1>\<in\>V>, <math|x<rsub|1>\<neq\>x<rsub|0>> it
    holds that\ 

    <\equation*>
      \<pi\><around*|(|x<rsub|0>|)><wide*|\<up-P\><rsub|x<rsub|0>><around*|(|H<rsub|x<rsub|1>>\<less\><wide|H|~><rsub|x<rsub|0>>|)>|\<wide-underbrace\>><rsub|<text|\Pescape
      probability\Q>>=C<rsub|eff><around*|(|x<rsub|0>,x<rsub|1>|)>.
    </equation*>
  </theorem>

  <\proof>
    Can be checked by next calculation.\ 

    <\align>
      <tformat|<table|<row|<cell|C<rsub|eff><around*|(|x<rsub|0>,x<rsub|1>|)>=>|<cell|<big|sum><rsub|y\<in\>V>I<rsub|x<rsub|0>,y><long-arrow|\<rubber-equal\>|<text|Ohm>><big|sum><rsub|y>\<mu\><rsub|x<rsub|0>,y><around*|(|U<around*|(|y|)>-U<around*|(|x<rsub|0>|)>|)>>>|<row|<cell|<long-arrow|\<rubber-equal\>|Lemma>>|<cell|\<pi\><around*|(|x<rsub|0>|)><big|sum><rsub|y><wide*|<frac|\<mu\><rsub|x<rsub|0>,y>|\<pi\><around*|(|x<rsub|0>|)>>|\<wide-underbrace\>><rsub|=P<around*|(|x<rsub|0>,y|)>>\<up-P\><rsub|y><around*|(|H<rsub|x<rsub|1>>\<less\>H<rsub|x<rsub|0>>|)><long-arrow|\<rubber-equal\>|Markov-property>\<pi\><around*|(|x<rsub|0>|)>\<up-P\><rsub|x<rsub|0>><around*|(|H<rsub|x<rsub|1>>\<less\><wide|H|~><rsub|x<rsub|0>>|)>.<qedhere>>>>>
    </align>
  </proof>

  <\remark>
    This will be helpful because <math|C<rsub|eff>> is monotone but it is a
    priori very hard to make any claims about monotonicity of the
    probability.
  </remark>

  <\theorem>
    <dueto|Commute time idendity><label|18.5>Consider <math|G> finite and
    <math|x<rsub|0>\<neq\>x<rsub|1>>. Then the commute time (LHS) satisfies

    <\equation*>
      \<up-E\><rsub|x<rsub|0>><around*|[|H<rsub|x<rsub|1>>|]>+\<up-E\><rsub|x<rsub|1>><around*|[|H<rsub|x<rsub|0>>|]>=R<rsub|eff><around*|(|x<rsub|0>,x<rsub|1>|)>\<pi\><around*|(|V|)>.
    </equation*>
  </theorem>

  <\corollary>
    Under the assumptions of Theorem <reference|18.5> the map
    <math|<around*|(|x,y|)>\<mapsto\>R<rsub|eff><around*|(|x,y|)>> is a
    metric on <math|V>, if one defines <math|R<rsub|eff><around*|(|x,x|)>=0>.
  </corollary>

  <\proof>
    Clearly we have <math|R<rsub|eff><around*|(|x,x|)>=0> by definition
    (exercise: prove that <math|R<rsub|eff><around*|(|x,y|)>=0> implies
    <math|x=y>). Symmetry follows from the above exercise. Lastly, for
    <math|x,y,z> we have\ 

    <\align>
      <tformat|<table|<row|<cell|\<up-E\><rsub|x><around*|[|H<rsub|z>|]>\<leq\>>|<cell|\<up-E\><rsub|x><around*|[|H<rsub|y>|]>+\<up-E\><rsub|y><around*|[|H<rsub|z>|]>>>|<row|<cell|\<up-E\><rsub|z><around*|[|H<rsub|x>|]>\<leq\>>|<cell|\<up-E\><rsub|y><around*|[|H<rsub|x>|]>+\<up-E\><rsub|z><around*|[|H<rsub|y>|]>.>>>>
    </align>

    Summing these two equations and using Theorem <reference|18.5> yields\ 

    <\equation*>
      R<rsub|eff><around*|(|x,z|)>\<leq\>R<rsub|eff><around*|(|x,y|)>+R<rsub|eff><around*|(|y,z|)>.
    </equation*>
  </proof>

  <\proof>
    <dueto|Proof of Theorem <reference|18.5>>Set
    <math|R=R<rsub|eff><around*|(|x<rsub|0>,x<rsub|1>|)>> and\ 

    <\equation*>
      \<varphi\><rsub|1><around*|(|x|)>=\<up-P\><rsub|x><around*|(|H<rsub|x<rsub|1>>\<less\>H<rsub|x<rsub|0>>|)>=1-\<varphi\><rsub|0><around*|(|x|)>
    </equation*>

    and <math|f<around*|(|x|)>=\<up-E\><rsub|x><around*|[|H<rsub|x<rsub|0>>|]>>.
    Then applying Green-Gauss twice gives us
    <math|<around|\<langle\>|\<varphi\><rsub|1>,-\<Delta\>f|\<rangle\>><rsub|\<pi\>>=<around|\<langle\>|-\<Delta\>\<varphi\><rsub|1>,f|\<rangle\>><rsub|\<pi\>>>.
    Also <math|f<around*|(|x<rsub|0>|)>=0> ,
    <math|\<Delta\>f<around*|(|x|)>=-1> for any <math|x\<neq\>x<rsub|0>>,
    <math|\<varphi\><rsub|1>> satisfies <eqref|DP> and\ 

    <\equation*>
      R<rsup|-1>=\<pi\><around*|(|x<rsub|0>|)>\<Delta\>\<varphi\><rsub|1><around*|(|x<rsub|0>|)>=-\<pi\><around*|(|x<rsub|1>|)>\<Delta\>\<varphi\><rsub|1><around*|(|x<rsub|1>|)>.
    </equation*>

    Thus we have\ 

    <\equation*>
      <around|\<langle\>|\<varphi\><rsub|1>,-\<Delta\>f|\<rangle\>><rsub|\<pi\>>=<big|sum><rsub|x\<neq\>x<rsub|0>>\<pi\><around*|(|x|)>\<varphi\><rsub|1><around*|(|x|)>=<big|sum><rsub|x>\<pi\><around*|(|x|)>\<varphi\><rsub|1><around*|(|x|)>
    </equation*>

    and

    <\equation*>
      <around|\<langle\>|-\<Delta\>\<varphi\><rsub|1>,f|\<rangle\>><rsub|\<pi\>>=-\<Delta\>
      \<varphi\><around*|(|x<rsub|1>|)>\<pi\><around*|(|x<rsub|1>|)>f<around*|(|x<rsub|1>|)>=<frac|1|R>\<cdot\>\<up-E\><rsub|x<rsub|1>><around*|[|H<rsub|0>|]>
    </equation*>

    By interchanging <math|0> and <math|1> the resistance does not change and
    we can use the above to arrive at the conclusion (by using
    <math|\<varphi\><rsub|1>+\<varphi\><rsub|0>\<equiv\>1>).\ 
  </proof>

  Given a set <math|A\<subseteq\>V> we can obtain a new set by collapsing
  <math|A>: <math|<around*|(|G<rprime|'>,\<mu\><rprime|'>|)>> is defined by\ 

  <\equation*>
    V<rprime|'>=<around*|(|V\<setminus\>A|)>\<cup\><around*|{|a|}>,
  </equation*>

  <\equation*>
    E<rprime|'>=<around*|{|<around*|{|x,y|}>\<in\>E\<mid\>x,y\<nin\>A|}>\<cup\><around*|{|<around*|{|a,x|}>\<mid\>\<exists\>y\<in\>A:<around*|{|x,y|}>\<in\>E,x\<neq\>a|}>
  </equation*>

  and the weights are given by

  <\equation*>
    \<mu\><rprime|'><rsub|x,y>=<choice|<tformat|<table|<row|<cell|\<mu\><rsub|x,y>.>|<cell|x,y\<in\>A>>|<row|<cell|<big|sum><rsub|z\<in\>A>\<mu\><rsub|z,y>>|<cell|x=a,y\<nin\>A>>>>>.
  </equation*>

  <\definition>
    <\itemize>
      <item><math|R<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>=R<rsub|eff><rprime|'><around*|(|x<rsub|0>,x<rsub|1>|)>>
      is defined to be the resistance between <math|x<rsub|0>>,
      <math|x<rsub|1>> in <math|G<rprime|'>>, obtained by collapsing
      <math|B<rsub|0>> to <math|x<rsub|0>>, <math|B<rsub|1>> to
      <math|x<rsub|1>>.\ 

      <item>If <math|G> is infinite and <math|B<rsub|0>> finite we take
      <math|A<rsub|n>\<nearrow\>V>, <math|A<rsub|n>> finite and set

      <\equation*>
        R<rsub|eff><around*|(|B<rsub|0>,+\<infty\>|)>:=lim<rsub|n\<rightarrow\>+\<infty\>>R<rsub|eff><around*|(|B<rsub|0>,A<rsup|\<complement\>><rsub|n>|)>.
      </equation*>

      The limit exists because the sequence on the RHS is increasing.\ 
    </itemize>
  </definition>

  <\theorem>
    <label|18.11>Let <math|<around*|(|G,\<mu\>|)>> be inifinite and
    <math|x<rsub|0>\<in\>V>. Then\ 

    <\equation*>
      \<pi\><around*|(|x<rsub|0>|)>\<up-P\><rsub|x<rsub|0>><around*|(|<wide|H|~><rsub|x>=+\<infty\>|)>=R<rsup|-1><rsub|eff><around*|(|x<rsub|0>,+\<infty\>|)>=C<around*|(|x<rsub|0>,+\<infty\>|)>
    </equation*>
  </theorem>

  The theorem has a useful corollary:\ 

  <\corollary>
    <label|18.12><math|x<rsub|0>> is recurrent (that is, <math|X> is
    recurrent) if and only if <math|C<around*|(|x<rsub|0>,+\<infty\>|)>=0>.\ 
  </corollary>

  <\proof>
    <dueto|Proof of Theorem <reference|18.11>>Let
    <math|A<rsub|n>=B<rsub|n><around*|(|x<rsub|0>|)>>. Collapse
    <math|A<rsub|n><rsup|\<complement\>>> to <math|x<rsub|1>>. Then\ 

    <\equation*>
      \<pi\><around*|(|x<rsub|0>|)>\<up-P\><rsub|x<rsub|0>><around*|(|<wide|H|~><rsub|x<rsub|0>>=+\<infty\>|)><long-arrow|\<rubber-leftarrow\>|n\<rightarrow\>+\<infty\>>\<pi\><around*|(|x<rsub|0>|)>\<up-P\><rsub|x<rsub|0>><around*|(|H<rsub|x<rsub|1>>\<less\><wide|H|~><rsub|x<rsub|0>>|)>=<frac|1|R<rsub|eff><around*|(|x<rsub|0>,x<rsub|1>|)>><long-arrow|\<rubber-rightarrow\>|n\<rightarrow\>+\<infty\>><frac|1|R<around*|(|x<rsub|0>,+\<infty\>|)>>.
    </equation*>

    This proves the formula.\ 
  </proof>

  <\exercise>
    Prove Corollary <reference|18.12>.\ 
  </exercise>

  <paragraph|Variational methods to estimate
  <math|C<around*|(|x<rsub|0>,+\<infty\>|)>>>Calculating the resistances on a
  huge graph can be quite cumbersome. <todo|Write this better> Let
  <math|<around*|(|G,\<mu\>|)>> be a finite weighted graph and let
  <math|B<rsub|0>,B<rsub|1>\<subseteq\>V> non-empty and disjoint. Define

  <\equation*>
    \<cal-F\><around*|(|B<rsub|0>,B<rsub|1>|)>\<assign\><around*|{|f\<in\>H<rsup|2>\<mid\>f<around*|\||<rsub|B<rsub|i>>|\<nobracket\>>\<equiv\>i|}>.
  </equation*>

  Moreover, set

  <\equation*>
    <wide|C|\<bar\>><rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>=min<around*|{|\<cal-E\><around*|(|f,f|)>:f\<in\>\<cal-F\><around*|(|B<rsub|0>,B<rsub|1>|)>|}>.
  </equation*>

  <\theorem>
    Suppose <math|G> is finite and take <math|B<rsub|0>> and <math|B<rsub|1>>
    as above\ 

    <\equation*>
      <wide|C|\<bar\>><rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>=C<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)><space|1em>
      <around*|(|=<frac|1|R<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>>|)>
    </equation*>
  </theorem>

  <\proof>
    Set <math|\<varphi\><around*|(|x|)>=\<up-P\><rsub|x><around*|(|H<rsub|B<rsub|1>>\<less\>H<rsub|B<rsub|0>>|)>>
    and <math|I<rsub|x,y>=\<mu\><rsub|x,y><around*|(|\<varphi\><around*|(|y|)>-\<varphi\><around*|(|x|)>|)>>.
    Then

    <\align>
      <tformat|<table|<row|<cell|R<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>=>|<cell|F<around*|(|I,B<rsub|0>|)>\<assign\><big|sum><rsub|x\<in\>B<rsub|0>><big|sum><rsub|y\<in\>V>I<rsub|x,y><space|1em>
      <text|(justify this by collapsing)>>>|<row|<cell|=>|<cell|<big|sum><rsub|x\<in\>B<rsub|0>><big|sum><rsub|y>\<mu\><rsub|x,y><around*|(|\<varphi\><around*|(|y|)>-\<varphi\><around*|(|x|)>|)>=<big|sum><rsub|x\<in\>B<rsub|0>>\<pi\><around*|(|x|)>\<Delta\>\<varphi\><around*|(|x|)>.>>>>
    </align>

    Also, using discrete Green-Gauss (Theorem <with|font-series|bold|??>),\ 

    <\equation*>
      \<cal-E\><around*|(|\<varphi\>,\<varphi\>|)>=\<cal-E\><around*|(|1-\<varphi\>,1-\<varphi\>|)>=<around|\<langle\>|-\<Delta\>\<varphi\>,f-\<varphi\>|\<rangle\>><rsub|\<pi\>>=<big|sum><rsub|x\<in\>B<rsub|0>>\<pi\><around*|(|x|)>\<Delta\>\<varphi\><around*|(|x|)>,
    </equation*>

    where the last equality comes from the fact that \ <math|\<varphi\>> is
    harmonic outside of <math|B<rsub|0>\<cup\>B<rsub|1>> and
    <math|\<varphi\>\<equiv\>0> on <math|B<rsub|1>>. Hence
    <math|\<cal-E\><around*|(|\<varphi\>,\<varphi\>|)>=R<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)><rsup|-1>>.
    Now, if <math|f\<in\>\<cal-F\><around*|(|B<rsub|0>,B<rsub|1>|)>>, Then

    <\equation*>
      \<cal-E\><around*|(|\<varphi\>,f-\<varphi\>|)>=<around|\<langle\>|-\<Delta\>\<varphi\>,\<varphi\>-\<varphi\>|\<rangle\>>=0,
    </equation*>

    again using that <math|\<Delta\>\<varphi\>\<equiv\>0> outside of
    <math|B<rsub|0>\<cup\>B<rsub|1>> and <math|f-\<varphi\>\<equiv\>0> on
    <math|B<rsub|0>\<cup\>B<rsub|1>>. We have thus shown that
    <math|\<cal-E\><around*|(|\<varphi\>,\<varphi\>|)>=-\<cal-E\><around*|(|\<varphi\>,f|)>>
    and so

    <\equation*>
      0\<leq\>\<cal-E\><around*|(|f-\<varphi\>,f-\<varphi\>|)>=\<cal-E\><around*|(|f,f|)>-\<cal-E\><around*|(|\<varphi\>,\<varphi\>|)><space|1em>
      <text|i.e., ><space|1em> \<cal-E\><around*|(|f,f|)>\<geq\>\<cal-E\><around*|(|\<varphi\>,\<varphi\>|)>.
    </equation*>

    Using that <math|\<varphi\>\<in\>\<cal-F\><around*|(|B<rsub|0>,B<rsub|1>|)>>
    we can take infiumum over all such <math|f> and obtain the desired
    equality.\ 
  </proof>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|15.1|<tuple|1|1>>
    <associate|18.11|<tuple|10|3>>
    <associate|18.12|<tuple|11|3>>
    <associate|18.4|<tuple|5|2>>
    <associate|18.5|<tuple|7|2>>
    <associate|DP|<tuple|1|1>>
    <associate|auto-1|<tuple|1|1>>
    <associate|auto-2|<tuple|1|1>>
    <associate|auto-3|<tuple|2|4>>
  </collection>
</references>

<\auxiliary>
  <\collection>
    <\associate|toc>
      <vspace*|2fn><with|font-series|<quote|bold>|math-font-series|<quote|bold>|font-size|<quote|1.19>|1<space|2spc>Random
      walks and electrical resistance> <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-1><vspace|1fn>

      <with|par-left|<quote|4tab>|Electrical Current
      <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-2><vspace|0.15fn>>

      <with|par-left|<quote|4tab>|Variational methods to estimate
      <with|mode|<quote|math>|C<around*|(|x<rsub|0>,+\<infty\>|)>>
      <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-3><vspace|0.15fn>>
    </associate>
  </collection>
</auxiliary>