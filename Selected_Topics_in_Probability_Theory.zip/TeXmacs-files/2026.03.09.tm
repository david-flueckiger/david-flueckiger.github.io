<TeXmacs|2.1.1>

<style|generic>

<\body>
  <section|Applications of the uniqueness of infinite clusters>

  We apply the uniqueness of infinite clusters to show several other
  interesting results. We start with a technical lemma. First for
  <math|k\<in\><around*|{|1,\<ldots\>,n|}>> define

  <\align>
    <tformat|<table|<row|<cell|K<rsub|k,n>=>|<cell|#<text| of disjoint
    clusters in <math|\<Lambda\><rsub|n>> connecting
    <math|\<partial\>\<Lambda\><rsub|n>> and
    <math|\<partial\>\<Lambda\><rsub|k>>><space|1em>
    <text|and>>>|<row|<cell|U<rsub|k,n>\<assign\>>|<cell|<around*|{|K<rsub|k,n>\<leq\>1|}>.>>>>
  </align>

  <todo|Image in the lecture notes>

  <\remark>
    The event <math|U<rsub|k,n>> is neither decreasing nor increasing as an
    event. However, <math|\<bbb-P\><rsub|p><around*|(|U<rsub|k,n>|)>> is
    increasing in <math|n> and decreasing in <math|k> (Exercise: check this).
    </remark>

  <\lemma>
    For any <math|\<varepsilon\>\<gtr\>0> and <math|k\<in\>\<bbb-N\>> there
    exists <math|n=n<around*|(|k,\<varepsilon\>|)>\<less\>+\<infty\>> such
    that\ 

    <\equation*>
      \<bbb-P\><rsub|p><around*|(|U<rsub|k,n>|)>\<gtr\>1-\<varepsilon\>,<space|1em>
      <text|for any <math|p\<in\><around*|[|0,1|]>>.>
    </equation*>
  </lemma>

  <\proof>
    Fix <math|\<varepsilon\>\<gtr\>0>, <math|k\<in\>\<bbb-N\>>. Define

    <\align>
      <tformat|<table|<row|<cell|O<rsub|n>\<assign\>>|<cell|<around*|{|p\<in\><around*|[|0,1|]>:<wide*|\<bbb-P\><rsub|p><around*|(|U<rsub|k,n>|)>|\<wide-underbrace\>><rsub|<text|continuous
      in <math|p> because it depends only on finitely many
      edges>>\<gtr\>1-\<varepsilon\>|}>.>>>>
    </align>

    which is open in <math|<around*|[|0,1|]>>. Then
    <math|O<rsub|n>\<subseteq\>O<rsub|n+1>> by the last remark. By the
    uniqueness of the infinite cluster (that is if it exists) we have

    <\equation*>
      <text|for any <math|p\<in\><around*|[|0,1|]>> there exist
      <math|n<around*|(|p|)>\<geq\>k> such that
      >\<bbb-P\><rsub|p><around*|(|U<rsub|k,n<around*|(|p|)>>|)>\<gtr\>1-\<varepsilon\>.
    </equation*>

    (If the above statement is not true one must have two infinite clusters).
    By this we have that

    <\equation*>
      <around*|[|0,1|]>=<big|cup><rsub|m\<geq\>k>O<rsub|m>
    </equation*>

    since <math|<around*|[|0,1|]>> is compact so there exists a finite
    subcovering <math|<around*|(|O<rsub|m<rsub|i>>|)><rsub|i=1><rsup|i<rsub|0>>>.
    The claim then follows by taking <math|n=max<rsub|i=1,\<ldots\>,i<rsub|0>>m<rsub|i>>
    (because <math|O<rsub|n>> are increasing sets we then have
    <math|O<rsub|n>=<around*|[|0,1|]>>).\ 
  </proof>

  <paragraph|Continuity of <math|\<theta\><around*|(|p|)>>>We will show that
  <math|p\<mapsto\>\<theta\><around*|(|p|)>> is continuous on
  <math|<around*|[|0,1|]>\<setminus\><around*|{|p<rsub|c>|}>>. Obviously
  <math|\<theta\>> is continuous on <math|<around*|[|0,p<rsub|c>|)>> but the
  other part is shown by the following theorem.

  <\theorem>
    <label|5.2>The map <math|p\<mapsto\>\<theta\><around*|(|p|)>> is
    continuous on <math|<around*|(|p<rsub|c>,1|]>>.
  </theorem>

  <\proof>
    Define <math|\<theta\><rsub|n><around*|(|p|)>\<assign\>\<bbb-P\><rsub|p><around*|(|0\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n>|)>>.
    Since the event <math|0\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n>>
    depends only on finitely many edges <math|\<theta\><rsub|n>> is
    continuous. Also <math|\<theta\><around*|(|p|)>=lim
    \<downarrow\>\<theta\><rsub|n><around*|(|p|)>> (which is a decreasing
    limit) so <math|\<theta\><around*|(|p|)>> is upper semicontinuous and
    since <math|\<theta\>> is decreasing, <math|\<theta\>> is left continuous
    (we won't need this in the proof).\ 

    Fix <math|p<rsub|0>\<gtr\>p<rsub|c>> arbitrary. We will show that
    <math|\<theta\><rsub|n>\<rightarrow\>\<theta\>> uniformly on
    <math|<around*|(|p<rsub|0>,1|]>>. To this end, fix
    <math|\<varepsilon\>\<gtr\>0> and pick <math|k\<in\>\<bbb-N\>> large such
    that <math|\<bbb-P\><rsub|p><around*|(|\<partial\>\<Lambda\><rsub|k>\<leftrightarrow\>\<infty\>|)>\<gtr\>1-\<varepsilon\>>.
    Also pick <math|n\<gtr\>k> large such that
    <math|\<bbb-P\><rsub|p><around*|(|U<rsub|k,n>|)>\<gtr\>1-\<varepsilon\>>
    for any <math|p\<in\><around*|[|0,1|]>>. Then

    <\align>
      <tformat|<table|<row|<cell|\<theta\><around*|(|p|)>\<geq\>>|<cell|\<bbb-P\><rsub|p><around*|(|<around*|{|0\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n>|}>\<cap\><around*|{|\<partial\>\<Lambda\><rsub|k>\<leftrightarrow\>\<infty\>|}>\<cap\>U<rsub|k,n>|)>>>|<row|<cell|\<geq\>>|<cell|\<bbb-P\><rsub|p><around*|(|0\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n>|)>-2\<varepsilon\>.>>>>
    </align>

    From this we obtain that <math|\<theta\><rsub|n><around*|(|p|)>\<geq\>\<theta\><around*|(|p|)>\<geq\>\<theta\><rsub|n><around*|(|p|)>-2\<varepsilon\><rsub|>>
    which is true for any <math|p>. Thus <math|\<theta\><rsub|n>> converges
    uniformly on <math|<around*|(|p<rsub|0>,1|]>>. This concludes the proof.
  </proof>

  <paragraph|Box crossings>

  <\proposition>
    Let <math|p\<in\><around*|[|0,1|]>> be such that
    <math|\<theta\><around*|(|p|)>\<gtr\>0>. Then\ 

    <todo| Bild 15>
  </proposition>

  <\equation*>
    lim<rsub|n\<rightarrow\>+\<infty\>>\<bbb-P\><rsub|p><around*|(|\<exists\><text|path
    from left to right in <math|\<Lambda\><rsub|n>>>|)>=1.\ 
  </equation*>

  <\proof>
    Let <math|\<varepsilon\>\<gtr\>0> and pick <math|k> large such that
    <math|\<bbb-P\><rsub|p><around*|(|\<Lambda\><rsub|k>\<leftrightarrow\>\<infty\>|)>\<geq\>1-\<varepsilon\>>.
    (possible because we are in the supercritical phase). Then for any
    <math|k\<geq\>n>,\ 

    <\align>
      <tformat|<table|<row|<cell|\<bbb-P\><rsub|p><around*|(|\<Lambda\><rsub|k>\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n>|)>>|<cell|=\<bbb-P\><rsub|p><around*|(|<todo|Bild
      16>|)>>>|<row|<cell|>|<cell|\<geq\>1-\<varepsilon\>.>>>>
    </align>

    By the square root trick this implies that <todo|Bild 17>

    <todo|Bild 18>
  </proof>

  <chapter|Subcritical phase>

  Since <math|\<theta\><around*|(|p|)>=0> for <math|p\<less\>p<rsub|c>> we
  know by the above proof that <math|\<theta\><rsub|n><around*|(|p|)>\<searrow\>0>
  for <math|p\<less\>p<rsub|c>>. Question: how fast does this happen?

  <\theorem>
    <dueto|Menshikov, 1987, Aizenmann-Busky, 1987><label|5.4>The following
    two statements hold:\ 

    <\enumerate>
      <item>For any <math|p\<less\>p<rsub|c>> there exists
      <math|c=c<around*|(|p|)>> such that

      <\equation*>
        \<bbb-P\><rsub|p><around*|(|0\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n>|)>\<leq\>\<mathe\><rsup|-c
        n><space|1em> <text|for all <math|n\<in\>\<bbb-N\>>>
      </equation*>

      <item>For all <math|p\<gtr\>p<rsub|c>> we have the <em|mean field lower
      bound>

      <\equation*>
        \<theta\><around*|(|p|)>\<geq\><frac|1|2><around*|(|p-p<rsub|c>|)>.
      </equation*>
    </enumerate>
  </theorem>

  From this one deduces the following corollary whose proof is left as an
  exercise to the reader.\ 

  <\corollary>
    For any <math|p\<less\>p<rsub|c>> we have

    <\equation*>
      \<chi\><around*|(|p|)>:=\<bbb-E\><rsub|p><around*|[|#<around*|{|x:x\<leftrightarrow\>0|}>|]>\<less\>+\<infty\>
    </equation*>
  </corollary>

  <\remark>
    Historically, people studied

    <\equation*>
      p<rsub|c><rprime|'>=inf<around*|{|p\<in\><around*|[|0,1|]>:\<chi\><around*|(|p|)>=+\<infty\>|}>
    </equation*>

    The previous theorem implies that <math|p<rsub|c><rprime|'>=p<rsub|c>>.
  </remark>

  The proof we are presenting is due to H. Dummil-Copin and V. Tassion. We
  first need a few definitions and lemmas.\ 

  <\definition>
    Let <math|S\<subseteq\>\<bbb-Z\><rsup|d>> be a finite set containing the
    origin. We define

    <\equation*>
      \<varphi\><rsub|p><around*|(|S|)>=<big|sum><rsub|<around*|(|x,y|)>\<in\>\<Delta\>S><wide*|p|\<wide-underbrace\>><rsub|\<bbb-P\><around*|(|<around*|{|x,y|}><text|open>|)>>\<bbb-P\><rsub|p><around*|(|0<long-arrow|\<rubber-leftrightarrow\>|S>x|)>=<big|sum><rsub|x,y\<in\>\<Delta\>S>\<bbb-P\><rsub|p><around*|(|x
      y<text| open>,x<long-arrow|\<rubber-leftrightarrow\>|S>0|)>
    </equation*>

    <\equation*>
      =\<bbb-E\><rsub|p><around*|[|#<text|edges open in <math|\<Delta\>S>
      connected to 0>|]>
    </equation*>

    If <math|0\<nin\>S> we define <math|\<varphi\><rsub|p><around*|(|S|)>\<assign\>0>.
  </definition>

  <\lemma>
    <label|5.6>If there is <math|S\<subseteq\>\<bbb-Z\><rsup|d>> finite
    containing the orogin such that <math|\<varphi\><rsub|p><around*|(|S|)>\<less\>1>.
    Then there exists <math|c=c<around*|(|p|)>> such that\ 

    <\equation*>
      \<theta\><rsub|n><around*|(|p|)>\<less\>\<mathe\><rsup|-c n>.
    </equation*>
  </lemma>

  <\proof>
    Assume we have such <math|S>. Fix <math|k\<in\>\<bbb-N\>> such that
    <math|S\<subseteq\>\<Lambda\><rsub|k>>. If
    <math|<around*|{|0\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n\<cdot\>k>|}>>
    occurs then there exists <math|x y\<in\>\<Delta\>S> such that\ 

    <\itemize>
      <item><math|0<long-arrow|\<rubber-leftrightarrow\>|S>x>

      <item><math|x y> is open and

      <item><math|y\<leftrightarrow\>\<partial\>\<Delta\><rsub|n k>>\ 
    </itemize>

    which are all events occuring disjointly. Now, using van-de Berg/Kesten
    inequality,\ 

    <\align>
      <tformat|<table|<row|<cell|\<theta\><rsub|n
      k><around*|(|p|)>=>|<cell|\<bbb-P\><rsub|p><around*|(|0\<leftrightarrow\>\<partial\>
      \<Lambda\><rsub|n k>|)>>>|<row|<cell|\<leq\>>|<cell|<big|sum><rsub|x
      y\<in\>\<Delta\>S>\<bbb-P\><rsub|p><around*|(|<around*|{|x<long-arrow|\<rubber-leftrightarrow\>|S>0|}>\<circ\><around*|{|x
      y <text|open>|}>\<circ\><around*|{|y\<leftrightarrow\>\<partial\>
      \<Lambda\><rsub|n k>|}>|)>>>|<row|<cell|\<leq\>>|<cell|<big|sum><rsub|x
      y>\<bbb-P\><rsub|p><around*|(|0<long-arrow|\<rubber-leftrightarrow\>|S>x,x
      y <text| open>|)><wide*|\<bbb-P\><rsub|p><around*|(|y\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n
      k>|)>|\<wide-underbrace\>><rsub|\<leq\>\<bbb-P\><rsub|p><around*|(|y\<leftrightarrow\>\<partial\><around*|(|y+\<Lambda\><rsub|<around*|(|n-1|)>k>|)>|)>=\<bbb-P\><rsub|p><around*|(|0\<leftrightarrow\>\<partial\>
      \<Lambda\><rsub|<around*|(|n-1|)>k>|)>>>>|<row|<cell|\<leq\>>|<cell|<wide*|\<varphi\><rsub|p><around*|(|S|)>|\<wide-underbrace\>><rsub|\<less\>1>\<bbb-P\><rsub|p><around*|(|0\<leftrightarrow\>\<partial\>
      \<Lambda\><rsub|<around*|(|n-1|)>k>|)>.>>>>
    </align>

    Iterate this to get the exponential decay.\ 
  </proof>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|5.2|<tuple|5|1>>
    <associate|5.4|<tuple|5|?>>
    <associate|5.6|<tuple|9|?>>
    <associate|auto-1|<tuple|1|1>>
    <associate|auto-2|<tuple|1|1>>
    <associate|auto-3|<tuple|2|?>>
    <associate|auto-4|<tuple|1|?>>
  </collection>
</references>

<\auxiliary>
  <\collection>
    <\associate|toc>
      <vspace*|1fn><with|font-series|<quote|bold>|math-font-series|<quote|bold>|1<space|2spc>Applications
      of the uniqueness of infinite clusters>
      <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-1><vspace|0.5fn>

      <with|par-left|<quote|4tab>|Continuity of
      <with|mode|<quote|math>|\<theta\><around*|(|p|)>>.
      <datoms|<macro|x|<repeat|<arg|x>|<with|font-series|medium|<with|font-size|1|<space|0.2fn>.<space|0.2fn>>>>>|<htab|5mm>>
      <no-break><pageref|auto-2><vspace|0.15fn>>
    </associate>
  </collection>
</auxiliary>