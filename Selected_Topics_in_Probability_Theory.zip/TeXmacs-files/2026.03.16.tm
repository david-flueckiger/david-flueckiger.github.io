<TeXmacs|2.1.1>

<style|generic>

<\body>
  <section|Percolation on <math|<around*|(|\<bbb-Z\><rsup|2>,E<rsub|2>|)>>>

  Recall the technique with the dual graph used in Peierl's argument for
  <math|<around*|(|\<bbb-Z\><rsup|2>,E<rsub|2>|)>>.\ 

  <paragraph|Intuition>If <math|p\<less\>p<rsub|c>> all components of
  <math|\<omega\>> are \Psmall\Q (we saw <math|\<bbb-P\><rsub|p><around*|(|0\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n>|)>\<leq\>\<mathe\><rsup|-c
  n>>). The \Pdual\Q circuits then should form an infinite cluster. If you
  open and close edges on <math|\<bbb-Z\><rsup|2>> randomly, either the graph
  or the dual should contain an infinite cluster. Since
  <math|\<omega\>\<sim\>\<bbb-P\><rsub|p>> we have
  <math|\<omega\><rsup|\<star\>>\<sim\>\<bbb-P\><rsub|1-p>> for
  <math|\<omega\><rsup|\<star\>><around*|(|e<rsup|\<star\>>|)>=1-\<omega\><around*|(|e|)>>
  and <math|1-p\<gtr\>p<rsub|c>> we would expect that
  <math|p<rsub|c>=<frac|1|2>>.\ 

  <\theorem>
    <label|7.1>Consider percolation on <math|<around*|(|\<bbb-Z\><rsup|2>,E<rsub|2>|)>>.
    Then <math|p<rsub|c>=<frac|1|2>> and <math|\<theta\><around*|(|<frac|1|2>|)>=0>.
    As a consequence, the function <math|p\<mapsto\>\<theta\><around*|(|p|)>>
    is continuous everywhere.\ 
  </theorem>

  Recall Proposition <reference|5.3> where we showed that for
  <math|\<theta\><around*|(|p|)>\<gtr\>0> we have
  <math|lim<rsub|n\<rightarrow\>+\<infty\>>\<bbb-P\><rsub|p><around*|(|<todo|Bild
  19>|)>=1>

  <\exercise>
    If <math|\<theta\><around*|(|p|)>\<gtr\>0> we have\ 

    <\equation*>
      lim<rsub|n\<rightarrow\>+\<infty\>>\<bbb-P\><rsub|p><around*|(|<todo|Bild
      20>|)>=1
    </equation*>

    Hint: Modify the proof of Proposition <reference|5.3>.
  </exercise>

  Define <math|R=<around*|[|1,m|]>\<times\><around*|[|1,n|]>\<cap\>\<bbb-Z\><rsup|2>>
  and <math|R<rprime|'>=<around*|(|<around*|[|1,m-1|]>\<times\><around*|[|1,n+1|]>|)>\<cap\>\<bbb-Z\><rsup|2>+<around*|(|<frac|1|2>,-<frac|1|2>|)>>,
  where <math|R<rprime|'>> is shifted because we want it to be an element of
  the dual graph. <todo|Bild von <math|R> und <math|R<rprime|'>> f�r ein
  <math|m,n\<in\>\<bbb-N\>>>

  Moreover consider the events

  <\equation*>
    H<around*|(|R|)>=<around*|{|<text|left and right of <math|R> are
    connected in <math|\<omega\>>>|}>
  </equation*>

  <\equation*>
    V<around*|(|R<rprime|'>|)>=<around*|{|<text|top and bottom of
    <math|R<rprime|'>> are connected in <math|\<omega\><rsup|\<star\>>>>|}>
  </equation*>

  <\lemma>
    <label|5.1>The sets <math|V<around*|(|R<rprime|'>|)>> and
    <math|H<around*|(|R|)>> form a partition of <math|\<Omega\>>.\ 
  </lemma>

  <todo|Illustrate this with a picture>

  <\proof>
    <with|font-shape|italic|Step 1: <math|V<around*|(|R<rprime|'>|)>> and
    <math|H<around*|(|R|)>> are disjoint> For this we need some elementary
    graph theory. In particular we use the fact that the graph
    <math|K<rsub|5>> is non-planar. If there is some <math|\<omega\>> in both
    sets we can identify each part of the boundary of their union with the
    edge of a graph and then show that this graph must be <math|K<rsub|5>>
    planar which is a contradiction. <todo|complete this proof>

    <with|font-shape|italic|Step 2: <math|V<around*|(|R<rprime|'>|)>\<cup\>H<around*|(|R|)>=\<Omega\>>>.
    <todo|picture in the notes> <math|H<around*|(|R|)>> occurs iff there is a
    left-right-corssing in the grey region and
    <math|V<around*|(|R<rprime|'>|)>> occurs iff there is a top-to-bottom
    corssing in the white region.\ 

    Set <math|I=> bound between grey and white.\ 

    All verticies of <math|I\<setminus\><around*|{|x,y,z,w|}>> have degree
    <math|2> and <math|x,y,z,w> have degree 1. Thus the edges of <math|I>
    must be a union of some cycles and two paths linking <math|x,y,z,w>.\ 

    Then start a walk such that grey stays on one side and white on the other
    in every step for example from <math|x>. Then the walk must end up at
    <math|y,z,w>. But then there must be a way either from top to bottom or
    left to right which concludes the proof.\ 
  </proof>

  If we take <math|m=n+1>. <todo|Bild 21> so we conclude
  <math|p<rsub|c>\<geq\><frac|1|2>>. Using

  <\equation*>
    \<bbb-P\><rsub|<frac|1|2>><around*|(|<todo|Bild 22>|)>=<frac|1|2>
  </equation*>

  we find <math|\<bbb-P\><rsub|<frac|1|2>><around*|(|0\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n+1>|)>\<geqslant\><frac|1|2n>>
  (exercise). We also know that for <math|p\<less\>p<rsub|c>>,
  <math|\<bbb-P\><rsub|p><around*|(|0\<leftrightarrow\>\<partial\>\<Lambda\><rsub|n>|)>\<leq\>\<mathe\><rsup|-c
  n>> so <math|<frac|1|2>\<geq\>p<rsub|c>>. This implies
  <math|p<rsub|c>=<frac|1|2>>. This concludes the proof of Theorem
  <reference|7.1>.

  <section|Russo-Seymour-Welsh-theorem>

  <\theorem>
    <dueto|RSW'1978><label|7.4>There exists
    <math|h\<in\>C<rsup|0><around*|(|<around*|[|0,1|]>;<around*|[|0,1|]>|)>>
    strictly increasing with <math|h<around*|(|0|)>=0>,
    <math|h<around*|(|1|)>=1> such that for any
    <math|p\<in\><around*|[|0,1|]>> and <math|n\<in\>\<bbb-N\>>,\ 

    <todo|Bild 23>
  </theorem>

  <\proof>
    Fix <math|p,n> and suppose that <math|6> divides <math|n>. Define
    <math|X> to be the RHS in the formula of the theorem. <todo|Proof>
  </proof>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|5.1|<tuple|2|?>>
    <associate|7.1|<tuple|1|?>>
    <associate|7.4|<tuple|3|?>>
    <associate|auto-1|<tuple|1|?>>
    <associate|auto-2|<tuple|1|?>>
    <associate|auto-3|<tuple|2|?>>
  </collection>
</references>