<TeXmacs|2.1.1>

<style|generic>

<\body>
  Note that <math|E=U I<long-arrow|\<rubber-equal\>|Ohm><frac|U<rsup|2>|R>=U<rsup|2>\<cdot\>C<long-arrow|\<rubber-equal\>|Ohm>I<rsup|2>R>
  (from physics). This translates to

  <\equation*>
    \<cal-E\><around*|(|f,f|)>=<frac|1|2><big|sum><rsub|x,y><wide*|\<mu\><rsub|x,y>|\<wide-underbrace\>><rsub|C><wide*|<around*|(|f<around*|(|y|)>-f<around*|(|x|)>|)><rsup|2>|\<wide-underbrace\>><rsub|U<rsup|2>>.
  </equation*>

  In the following we want to minimize the energy and this intuition helps
  understanding things.

  <\definition>
    <label|19.1><math|J=<around*|(|J<rsub|x,y>|)><rsub|x,y\<in\>V>> is called
    <em|flow from <math|B<rsub|0>> to <math|B<rsub|1>>> if\ 

    <\enumerate>
      <item><math|<big|sum><rsub|y\<in\>V>J<rsub|x,y>=0> if
      <math|x\<nin\>B<rsub|1>\<cup\>B<rsub|0>>

      <item><math|J<rsub|x,y>=-J<rsub|x,y>>

      <item><math|J<rsub|x,y>=0> if <math|x\<nsim\>y>.\ 
    </enumerate>

    The <em|total flow out of <math|B<rsub|0>>> is given by

    <\equation*>
      F<around*|(|J,B<rsub|0>|)>=<big|sum><rsub|x\<in\>B<rsub|0>><big|sum><rsub|y\<sim\>x>J<rsub|x,y>,
    </equation*>

    sometimes also called the flux of <math|J>.\ 
  </definition>

  <\exercise>
    Show that if <math|G> is finite then <math|F<around*|(|J,B<rsub|0>|)>=-F<around*|(|J,B<rsub|1>|)>>.
    Show that it does not hold in general when <math|G> is infinite (then one
    can \Pmove things to infinity\Q).\ 
  </exercise>

  What is the difference between flow and current?<todo|Write something here>

  <\definition>
    We define

    <\equation*>
      E<around*|(|I,J|)>=<frac|1|2><big|sum><rsub|x><big|sum><rsub|y\<sim\>x>I<rsub|x,y>J<rsub|x,y><frac|1|\<mu\><rsub|x,y>>
    </equation*>
  </definition>

  We'd like to study the problem:\ 

  <\equation>
    <label|vp2>R<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>=inf<around*|{|E<around*|(|J,J|)>:<text|<math|J>
    is flow from <math|B<rsub|0>> to <math|B<rsub|1>> with
    <math|F<around*|(|J,B<rsub|0>|)>=1>>|}>.\ 
  </equation>

  <\theorem>
    <dueto|Thompson's principle><label|19.3>If <math|<around*|(|G,\<mu\>|)>>
    is finite, then <math|R<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>> is
    indeed the resistance between <math|B<rsub|0>> and <math|B<rsub|1>>.
  </theorem>

  <\proof>
    Let <math|G> be finite and let <math|J> be as in <eqref|vp2> and
    <math|f\<in\>\<cal-F\><around*|(|B<rsub|0>,B<rsub|1>|)>>. Then\ 

    <\align>
      <tformat|<table|<row|<cell|<frac|1|2><big|sum><rsub|x><big|sum><rsub|y>J<rsub|x,y><around*|(|f<around*|(|y|)>-f<around*|(|x|)>|)>=>|<cell|<frac|1|2><big|sum><rsub|x,y>-J<rsub|x,y>f<around*|(|x|)>-<frac|1|2><big|sum><rsub|x,y>J<rsub|x,y>f<around*|(|x|)>>>|<row|<cell|=>|<cell|-<big|sum><rsub|x><wide*|f<around*|(|x|)>|\<wide-underbrace\>><rsub|\<in\>\<cal-F\><around*|(|B<rsub|0>,B<rsub|1>|)>><big|sum><rsub|y\<sim\>x>J<rsub|x,y>>>|<row|<cell|=>|<cell|-<big|sum><rsub|x\<in\>B<rsub|1>><wide*|f<around*|(|x|)>|\<wide-underbrace\>><rsub|\<equiv\>1><big|sum><rsub|y\<sim\>x>J<rsub|x,y>>>|<row|<cell|=>|<cell|-F<around*|(|J,B<rsub|1>|)><long-arrow|\<rubber-equal\>|Exercise>F<around*|(|J,B<rsub|0>|)>=1.>>>>
    </align>

    Hence if <math|\<varphi\><around*|(|x|)>=\<up-P\><rsub|x><around*|(|H<rsub|B<rsub|1>>\<less\>H<rsub|B<rsub|0>>|)>=U<around*|(|x|)>>
    solves <eqref|DP> and <math|I<rsub|x,y>=\<mu\><rsub|x,y><around*|(|\<varphi\><around*|(|y|)>-\<varphi\><around*|(|x|)>|)>>,
    then\ 

    <\equation*>
      E<around*|(|I,J|)>=<frac|1|2><big|sum><rsub|x><big|sum><rsub|y><frac|1|\<mu\><rsub|x,y>>I<rsub|x,y>J<rsub|x,y>=<frac|1|2><big|sum><rsub|x,y>J<rsub|x,y><wide|<around*|(|\<varphi\><around*|(|y|)>-\<varphi\><around*|(|x|)>|)>|\<wide-overbrace\>><rsup|\<in\>\<cal-F\><around*|(|B<rsub|0>,B<rsub|1>|)>>=1.
      </equation*>

    <math|I> is not feasable for <eqref|vp2> since
    <math|F<around*|(|B<rsub|0>,I|)>=C<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>>
    so we set <math|I<rprime|'>=R<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>>I.
    Then\ 

    <\equation*>
      E<around*|(|I<rprime|'>,J|)>=R<around*|(|B<rsub|0>,B<rsub|1>|)><space|1em>
      <text|and thus also ><space|1em> E<around*|(|I<rprime|'>,I<rprime|'>|)>=R<rsub|eff><around*|(|B<rsub|0>,B<rsub|1>|)>,
    </equation*>

    hence for any <math|J> as in <eqref|vp2>,\ 

    <\equation*>
      0\<leq\>E<around*|(|J-I<rprime|'>,J-I<rprime|'>|)>=\<cdots\>=E<around*|(|J,J|)>-E<around*|(|I<rprime|'>,I<rprime|'>|)>,
    </equation*>

    proving the statement.
  </proof>

  <\example>
    <todo|See notes> in the picture every edge between <math|x<rsub|0>> and
    <math|x<rsub|1>> has resistance 1 hence
    <math|R<around*|(|x<rsub|0>,x<rsub|1>|)>=3> and
    <math|C<around*|(|x<rsub|0>,x<rsub|1>|)>=<frac|1|3>.> On binary tree we
    then have resistance <math|<around*|(|<frac|1|2>|)><rsup|d<around*|(|x<rsub|0>,\<cdot\>|)>>>
    or something like this. <todo|make this understandable>.
  </example>

  <\corollary>
    <label|19.4>Let <math|<around*|(|G,\<mu\>|)>> be finite and
    <math|B<rsub|0>,B<rsub|1>> as usual.\ 

    <\enumerate>
      <item><label|19.4, i><math|\<mu\>\<mapsto\>C<around*|(|B<rsub|0>,B<rsub|1>|)>>
      is coordinate wise increasing in <math|\<mu\>>.\ 

      <item><label|19.4, ii>\QCutting\Q. Deleting an edge (i.e., setting its
      conductance to zero) decreases the conductance.

      <item><label|19.4, iii>\QShorting\Q. Identifiying verticies <math|x,y>
      (that is, formally, setting <math|\<mu\><rsub|x,y>=+\<infty\>>)
      increases the conductance.\ 
    </enumerate>
  </corollary>

  <\proof>
    <todo|>
  </proof>

  <\example>
    SRW on <math|\<bbb-Z\><rsup|2>> is recurrent if and only if
    <math|C<rsub|eff><around*|(|0,+\<infty\>|)>=0>. Short
    <math|\<partial\>\<Lambda\><rsub|n>> to one vertex (for all
    <math|n\<in\>\<bbb-N\>>) but then <todo|<math|R=<frac|1|4>,R=<frac|1|12>,R=<frac|1|20>>
    on <math|\<partial\>\<Lambda\><rsub|1>,\<partial\>\<Lambda\><rsub|2>,\<partial\>\<Lambda\><rsub|3>>
    we obtain <math|R<rsub|eff>=+\<infty\>> hence the conductance is
    <math|0>.>\ 
  </example>
</body>

<\initial>
  <\collection>
    <associate|page-medium|paper>
  </collection>
</initial>

<\references>
  <\collection>
    <associate|19.1|<tuple|1|1|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|19.3|<tuple|3|1|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|19.4|<tuple|5|?|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|19.4, i|<tuple|1|?|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|19.4, ii|<tuple|2|?|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|19.4, iii|<tuple|3|?|../.TeXmacs/texts/scratch/no_name_10.tm>>
    <associate|vp2|<tuple|1|1|../.TeXmacs/texts/scratch/no_name_10.tm>>
  </collection>
</references>